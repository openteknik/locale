<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'styler' => 'Stiller', 
	 'styler:brown' => 'Kahverengi', 
	 'styler:blue' => 'Mavi', 
	 'styler:darkyellow' => 'Koyu Sarı', 
	 'styler:montego' => 'Montego', 
	 'styler:green' => 'Yeşil', 
	 'styler:pink' => 'Pembe', 
	 'styler:red' => 'Kırmızı', 
	 'styler:select:color' => 'Aşağıdaki rengi seçin', 
	 'styler:save:error' => 'Ayarlar saklanmayabilir', 
	 'styler:saved' => 'Ayarlar saklandı', 
));