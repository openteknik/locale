<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'ossn:notifications:ossnpoke:poke' => '%s sizi dürtdi!', 
	 'user:poked' => '%s öğesini pohpohladınız!', 
	 'user:poke:error' => '%s kurcalanamıyor! Lütfen daha sonra yeniden deneyin.', 
	 'poke' => 'Dürt', 
));