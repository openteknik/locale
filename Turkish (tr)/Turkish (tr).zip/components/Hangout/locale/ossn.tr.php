<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'hangout' => 'Sesli/Görüntülü Arama', 
));