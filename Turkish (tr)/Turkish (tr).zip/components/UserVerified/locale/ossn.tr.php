<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'userverified:success' => 'Başarıyla doğrulandı', 
	 'userverified:failed' => 'Doğrulanamadı', 
	 'userverified:verified' => 'Doğrulanmış Profil', 
	 'userverified:verify' => 'Doğrula', 
	 'userverified:unverify' => 'Doğrulamayı kaldır', 
	 'userverified:unverifiy:success' => 'Doğrulanmadı', 
	 'userverified:unverifiy:failed' => 'Doğrulanmamış başarısız oldu', 
));