<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'censorship' => 'Sansür', 
	 'censorship:add:words' => 'Aşağıdaki sözcükleri girin', 
	 'censorship:add:words:note' => 'Virgül (,) ile ayrılmış sözcükleri girin. Word1, Word2, Word3', 
	 'censorship:replace:string' => 'Hatalı sözcüklerin yerine konmasını istediğiniz dizgiyi girin', 
	 'censorship:fields:error' => 'Tüm alanlara veri girilmesi zorunludur', 
	 'censorship:saved' => 'Ayar kaydedildi', 
	 'censorship:save:error' => 'Ayarlar saklanmayabilir', 
));