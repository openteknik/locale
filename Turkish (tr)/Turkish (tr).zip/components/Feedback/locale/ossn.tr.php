<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'feeback:desc' => 'Geribildiriminizi aşağıya yazın', 
	 'feeback:rate' => 'Genel deneyim:', 
	 'feedback:submit' => 'Geribildirim gönder', 
	 'feedback:added' => 'Feetback eklendi', 
	 'feedback:add:failed' => 'Geribildirim eklenemez', 
	 'feedback:from' => 'Başlangıç', 
	 'feedback:rate' => 'Oran', 
	 'feedback:delete' => 'Sil', 
	 'feedback:message' => 'İleti', 
	 'feedback' => 'Geribildirim', 
	 'feedback:deleted' => 'Geribildirim silindi', 
	 'feedback:deleted:error' => 'Geribildirim silinemez', 
));