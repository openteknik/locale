<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'groupinvite:widget:title' => 'Bir arkadaşı davet et', 
	 'groupinvite:widget:desc' => 'Arkadaşlarınızı virgülle ayrılmış olarak seçin ve gönder düğmesini tıklatın.', 
	 'groupinvite:invite' => 'Davet Et', 
	 'groupinvite:sent' => 'Davet gönderildi, arkadaşınız davetiniz hakkında bir bilgi alamayacak', 
	 'ossn:notifications:groupinvite' => '%s sizigroup%s grubuna katılmanız için davet etti', 
));