<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'firstlogin' => 'İlk Oturum Açma', 
	 'first:login:url' => 'URL \' yi girin', 
	 'first:login:placeholder' => 'https://mysiteurl.com/[USERNAME]', 
	 'firstlogin:saved' => 'Ayarlar kaydedildi', 
	 'firstlogin:cannot:save' => 'Ayarlar saklanamıyor', 
	 'first:login:info' => 'Aşağıda URL \' de kullanabileceğiniz etiketler: <br /> [ USERNAME], oturum açmış olan kullanıcının kullanıcı adıdır.<br /> [ GUID], loggedin kullanıcısının kimliğidir.', 
));