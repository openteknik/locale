<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'stories' => 'Hikayeler', 
	 'stories:title' => 'Başlık (İsteğe Bağlı)', 
	 'stories:story:add' => 'Hikaye Ekle', 
	 'stories:added' => 'Hikayeler kaydedildi', 
	 'stories:add:failed' => 'Hikayeler sisteme eklenemez', 
	 'stories:deleted:status' => 'Durum silindi', 
	 'stories:delete:failed' => 'Hikayeler silinemez', 
	 'stories:cron' => 'Barındırma sağlayıcınızdan, barındırma hesabınıza aşağıdaki sıralanmış işi eklemesini isteyin. Bu, eski öyküleri silecek', 
));