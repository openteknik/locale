<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'userstats:friends' => 'Arkadaşlar', 
	 'userstats:comments' => 'Açıklamalar', 
	 'userstats:reactions' => 'Tepkiler', 
	 'userstats:posts' => 'Tartışma Öğeleri', 
));