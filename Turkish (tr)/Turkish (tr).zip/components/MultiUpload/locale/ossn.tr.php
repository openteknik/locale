<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'multiupload:text' => 'Lütfen duvar postanız için bir metin girin!', 
));