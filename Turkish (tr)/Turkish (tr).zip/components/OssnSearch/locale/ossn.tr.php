<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'ossn:search' => 'Ara', 
	 'result:type' => 'SONUç TIPI', 
	 'search:result' => '%s için arama sonuçları', 
	 'ossn:search:topbar:search' => 'Arama grupları, arkadaşlar ve daha fazlası.', 
	 'ossn:search:no:result' => 'Sonuç bulunamadı!', 
));