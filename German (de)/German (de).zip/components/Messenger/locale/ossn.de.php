<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
$de = array(
	'messenger' => 'Messenger-Software',
	'messenger:head' => 'Sie k�nnen die folgenden Anmeldedaten f�r Ihren Messenger verwenden:',
	'messenger:hostname' => 'Hostnamen',
	'messenger:username' => 'Benutzername',
	'messenger:password' => 'Passwort',
	'messenger:bottom' => 'Diese Software ist f�r Windows x64-Betriebssysteme',
	'messenger:download' => 'Messenger herunterladen',
	
	'messenger:use' => 'Messenger',
);
ossn_register_languages('de', $de);