<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'birthdays:upcoming' => 'Geburtstage bevorstehende Tage', 
	 'birthdays:on' => '%s haben Geburtstag am %d', 
	 'birthdays:nobirthday' => 'Keine nächsten Geburtstage!', 
));