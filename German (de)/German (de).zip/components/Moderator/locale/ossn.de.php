<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'moderator' => 'Moderator machen', 
	 'can_moderate' => 'Benutzer können moderaten Beiträge, Kommentare, Fotos, Gruppen', 
	 'delete:cover' => 'Abdeckung löschen', 
	 'moderator:yes' => 'Ja', 
	 'moderator:no' => 'Nein', 
	 'moderate:users' => 'Moderate Benutzer', 
	 'moderator:delete:user' => 'Benutzer löschen', 
	 'moderator:select' => 'Bitte auswählen', 
));