<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'userverified:success' => 'Erfolgreich geprüft', 
	 'userverified:failed' => 'Verifiziert fehlgeschlagen', 
	 'userverified:verified' => 'Verifiziert Profil', 
	 'userverified:verify' => 'Prüfen', 
	 'userverified:unverify' => 'Nicht-ify', 
	 'userverified:unverifiy:success' => 'Nicht verifiziert erfolgreich', 
	 'userverified:unverifiy:failed' => 'Nicht verifiziert fehlgeschlagen', 
));