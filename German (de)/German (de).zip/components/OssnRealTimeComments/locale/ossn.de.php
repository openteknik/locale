<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'rtcomments:typing' => 'Jemand tippt einen Kommentar ...', 
));