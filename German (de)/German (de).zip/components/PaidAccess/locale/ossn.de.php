<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    Core Team <info@openteknik.com>
 * @copyright (C) OPENTEKNIK LLC
 * @license   OPENTEKNIK LLC, COMMERCIAL LICENSE v1.0 https://www.openteknik.com/license/commercial-license-v1
 * @link      https://www.openteknik.com/
 */
$de = array(
	'paidaccess' => 'Bezahlter Zugang',
	'paidaccess:stripe' => 'Stripe',
	'paidaccess:api:screat:key' => 'Geheimer Schl�ssel:',
	'paidaccess:api:public:key' => '�ffentlicher Schl�ssel',
	'paidaccess:done' => 'Die Zahlung wurde erfolgreich durchgef�hrt. Sie k�nnen jetzt die Website nutzen.',
	'paidaccess:failed' => 'Benutzer konnte nicht hinzugef�gt werden, aber Ihre Zahlung wurde durchgef�hrt. Bitte kontaktieren Sie den Website-Besitzer unter xx, um das Problem zu l�sen.',
	
	'paidaccess:card' => 'Kartennummer',
	'paidaccess:cvc' => 'CVC',
	'paidaccess:exp' => 'G�ltig bis (MM/JJJJ)',
	
	'paidaccess:ammount' => 'Betrag',
	'paidaccess:create' => 'Zahlung durchf�hren',
	'payment:continue' => 'Bezahlen Sie f�r das Mitgliedschaft, um fortzufahren',
	'paidaccess:membership:ammount' => 'Mitgliedschaftspreis (in USD)',
	
	'paidaccess:admin:save:error' => 'Einstellungen konnten nicht gespeichert werden. Bitte stellen Sie sicher, dass alle Felder ausgef�llt sind',
	'paidaccess:admin:saved' => 'Einstellungen gespeichert',
	'paidaccess:failed' => 'Zahlung fehlgeschlagen',
	'paidaccess:done' => 'Zahlung wurde verarbeitet',
	
	'paiduser:markpaid' => 'Als bezahlt markieren',
	'paidaccess:usermarkedpaid' => 'Benutzer ist jetzt als bezahlt markiert!',
	'paidaccess:usermarkedpaid:false' => 'Benutzer konnte nicht als bezahlt markiert werden',
	'paidaccess:usermarkedunpaid' => 'Benutzer ist als nicht bezahlt markiert',
	'paidaccess:usermarkedunpaid:false' => 'Benutzer konnte nicht als nicht bezahlt markiert werden',
	'paiduser:markunpaid' => 'Als nicht bezahlt markieren',
	'paidaccess:paypal' => 'PayPal',
	'paidaccess:paypal:client:id' => 'Client-ID',
	'paidaccess:paypal:client:secret' => 'Client-Geheimnis',
	'paidaccess:default' => 'Standardoption ausw�hlen',
	'paidaccess:currency:default' => 'Bitte beachten Sie, dass die Standardw�hrung USD ist. Wenn Sie dies �ndern m�chten, m�ssen Sie einige Dateien bearbeiten!',
	'paidaccess:support:email' => 'Support-E-Mail-Adresse',
	'paidaccess:paypal:error' => 'Es gibt ein Problem mit der Zahlungskonfiguration. Bitte kontaktieren Sie den Website-Administrator unter %s, um das Problem zu l�sen!',
	'paidaccess:paypal:failed' => 'Die Zahlung konnte nicht abgeschlossen werden. Bitte kontaktieren Sie den Website-Administrator unter %s f�r weitere Details!',
	'paidaccess:paywithpp' => 'Mit PayPal bezahlen',
	'paidaccess:paypal:success' => 'Sie haben Ihre Mitgliedschaft erfolgreich bezahlt!',
	
	'paidaccess:wallet:moved' => 'Die Einstellungen f�r den bezahlten Zugang wurden in das Wallet verschoben, das aktualisierte Zahlungsmethoden enth�lt. Jetzt k�nnen Benutzer des bezahlten Zugangs das Wallet nutzen, um Guthaben aufzuladen, und der bezahlte Zugang verwendet das Benutzerguthaben f�r die Abbuchung.',
	'paidaccess:wallet' => 'Bitte stellen Sie sicher, dass Sie �ber ausreichendes Guthaben in Ihrem Wallet verf�gen. Sie k�nnen dies auf der �bersichtsseite pr�fen. F�r weitere Details wenden Sie sich bitte an unseren Support %s',
);

ossn_register_languages('de', $de);