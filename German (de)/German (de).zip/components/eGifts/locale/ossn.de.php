<?php
/**
 * Open Source Social Network
 *
 * @package Open Source Social Network
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OPENTEKNIK  LLC, COMMERCIAL LICENSE
 * @license   OPENTEKNIK  LLC, COMMERCIAL LICENSE, COMMERCIAL LICENSE https://www.openteknik.com/license/commercial-license-v1
 * @link      http://www.opensource-socialnetwork.org/licence
 */
ossn_register_languages('de', array(
	'egifts' => 'eGeschenke',
	'egifts:gift' => 'Geschenk',
	'egifts:title' => 'Titel',
	'egifts:desc' => 'Beschreibung',
	'egifts:pricepoints' => 'Preis oder Punkte',
	'egifts:price' => 'Preis',
	'egifts:payment:mode' => 'Zahlungsart',
	'egifts:wallet' => 'Wallet',
	'egifts:image' => 'Bild (512x512)',
	'egifts:userpoints' => 'Benutzerpunkte',
	'egifts:all:fields' => 'Bitte stellen Sie sicher, dass alle Felder ausgef�llt sind',
	'egifts:added' => 'Geschenk wurde hinzugef�gt',
	'egifts:add:failed' => 'Das Geschenk konnte dem System nicht hinzugef�gt werden!',
	'egifts:controls' => 'Steuerung',
	'egifts:image:tochange' => 'Bitte nur ein Bild hochladen, wenn Sie es �ndern m�chten (512x512) oder stellen Sie sicher, dass es quadratisch ist (gleiche Breite und H�he).',
	'egifts:edited' => 'Geschenk wurde bearbeitet',
	'egifts:edit:failed' => 'Bearbeitung des Geschenks ist fehlgeschlagen!',
	'egifts:delete:failed' => 'L�schen des Geschenks fehlgeschlagen',
	'egifts:deleted' => 'Geschenk wurde gel�scht!',
	'egifts:list' => 'Listen',
	'egifts:nogift:error' => 'Ein solches Geschenk existiert nicht!',
	'egifts:points' => 'Punkte',
	'egifts:send' => 'eGeschenk senden',
	'egift:select:friends' => 'Freunde ausw�hlen',
	'egift:send' => 'Senden',
	'egift:sent' => 'eGeschenk an (%s) Freunde gesendet',
	'egifts:list:sent' => 'Gesendete eGeschenke',
	'egifts:received' => 'Erhaltene eGeschenke',
	'egifts:received:text' => 'Liste aller erhaltenen eGeschenke!',
	'egifts:cap' => 'Senden und empfangen Sie eGeschenke von Ihren Freunden. �berraschen Sie Ihre Freunde mit einem sch�nen Geschenk!',
	'ossn:notifications:egift' => '%s hat Ihnen ein Geschenk %s gesendet!',
	'egift:received:by' => 'Von - ',
	'egift:lessuserpoints' => 'Geschenk kann nicht gesendet werden, da Sie nicht gen�gend Punkte haben. Erforderliche Punkte f�r die genannten Freunde sind %s',
	'egift:lessbalance' => 'Ihr Guthaben reicht nicht aus, um das Geschenk zu senden. Bitte laden Sie zuerst Ihr Wallet auf. Erforderlicher Betrag: %s %s',
	'egifts:wallet:required' => 'Die Wallet-Komponente muss aktiviert sein!',
	'egifts:userpoints:required' => 'Die Benutzerpunkte-Komponente muss aktiviert sein!',
	'egifts:add' => 'Hinzuf�gen',
));