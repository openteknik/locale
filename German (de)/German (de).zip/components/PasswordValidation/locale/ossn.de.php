<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'passwordvalidation:atleast' => 'mindestens <em>%s<em> Zeichen lang sein', 
	 'passwordvalidation:passwordmustbe' => 'Ihr Kennwort muss:', 
	 'passwordvalidation:capitalletter' => 'enthalten einen Kapitalbrief', 
	 'passwordvalidation:lowerletter' => 'einen Kleinbuchstaben enthalten', 
	 'passwordvalidation:number' => 'enthält eine Zahl', 
	 'passwordvalidation:error' => 'Dieses Kennwort entspricht nicht den Anforderungen', 
));