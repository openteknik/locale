<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'mobilelogin' => 'Mobil', 
	 'mobilelogin:username' => 'Benutzername/Email/Mobile', 
	 'mobilelogin:invalid:mobile' => 'Ungültige Mobilnummer', 
	 'mobilelogin:num' => '+1245678910', 
	 'mobilelogin:mobile:exists' => 'Eine Mobilnummer ist bereits im Gebrauch', 
));