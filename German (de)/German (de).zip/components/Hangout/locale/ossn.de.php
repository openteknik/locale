<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'hangout' => 'Audio/Video-Aufruf', 
));