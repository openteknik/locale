<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'userstats:friends' => 'Freunde', 
	 'userstats:comments' => 'Kommentare', 
	 'userstats:reactions' => 'Reaktionen', 
	 'userstats:posts' => 'Beiträge', 
));