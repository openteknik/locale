<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'accesscode' => 'Zugriffscode', 
	 'accesscode:saved' => 'Der Zugriffscode wurde gespeichert.', 
	 'accesscode:save:error' => 'Der Zugriffscode kann nicht gespeichert werden.', 
	 'accesscode:register:code' => 'Zugriffscode/Signup-Code', 
	 'access:code:error' => 'Ungültiger Zugriffscode', 
));