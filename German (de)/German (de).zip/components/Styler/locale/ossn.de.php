<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'styler' => 'Styler', 
	 'styler:brown' => 'Braun', 
	 'styler:blue' => 'Blau', 
	 'styler:darkyellow' => 'Dunkelgelb', 
	 'styler:montego' => 'Montego', 
	 'styler:green' => 'Grün', 
	 'styler:pink' => 'Rosa', 
	 'styler:red' => 'Rot', 
	 'styler:select:color' => 'Farbe unten auswählen', 
	 'styler:save:error' => 'Einstellungen können nicht gespeichert werden', 
	 'styler:saved' => 'Einstellungen wurden gespeichert', 
));