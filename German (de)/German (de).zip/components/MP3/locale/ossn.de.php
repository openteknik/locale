<?php
/**
 * Open Source Social Network
 *
 * @package   (openteknik.com).ossn
 * @author    OSSN Core Team <info@openteknik.com>
 * @copyright (C) OPENTEKNIK LLC
 * @license   OPENTEKNIK LLC, COMMERCIAL LICENSE v1.0 https://www.openteknik.com/license/commercial-license-v1
 * @link      https://www.openteknik.com
 */
$de = array(
	'mp3file' => 'MP3',
    'mp3file:add' => 'MP3 hinzuf�gen',
	'mp3file:desc' => 'Beschreibung',
	'mp3file:desc:optional' => 'MP3-Beschreibung (optional)',
	'mp3file:group' => 'Gruppe',
	'mp3file:select' => 'Datei ausw�hlen',
	'mp3file:add:failed' => 'Audio konnte nicht hinzugef�gt werden',
	'mp3file:add:failed:1' => 'Audiodatei kann von Ihrem Ger�t nicht hinzugef�gt werden.',
	'mp3file:added' => 'MP3-Datei wurde hinzugef�gt',
	'mp3file:group' => 'Gruppe',
	'mp3file:join:group' => 'Sie m�ssen der Gruppe beitreten, um diese Datei zu sehen',
	'mp3file:com:wall:added' => 'hat eine MP3-Audiodatei hinzugef�gt.',
	'mp3file:com:my' => 'Meine Audios',
	'mp3file:com:all' => 'Alle Audios',
	'mp3file:com:add' => 'Audio hinzuf�gen',
	'ossn:notifications:comments:entity:file:mp3file' => "%s hat Ihre Audiodatei kommentiert",
	'ossn:notifications:like:entity:file:mp3file' => '%s hat Ihre Audiodatei gefallen',
	'mp3file:delete:failed' => 'Audio konnte nicht gel�scht werden',
	'mp3file:deleted' => 'Audio wurde gel�scht',
	'mp3file:rights' => 'Ich habe die Rechte, diese Audiodatei hochzuladen.',
	'mp3file:rights:error' => 'Sie m�ssen die Rechte besitzen, um diese Musik hochzuladen!',
);
ossn_register_languages('de', $de);