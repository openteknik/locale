<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    Core Team
 * @copyright (C) OpenTeknik LLC
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
ossn_register_languages('de', array(
	'membershiptier'                                => 'Mitgliedschaftsstufe',
	'membershiptier:gadgets:available'             => 'Verf�gbare Module',
	'membershiptier:disallowed'                    => 'Nicht erlaubte Aktionen',
	'membershiptier:subtext'                       => 'Ein Mitglied mit dieser Stufe kann nur die erlaubten Aktionen ausf�hren. Bitte entsprechend einstellen.',
	'membershiptier:settings'                      => 'Mitgliedschaftsstufen verwalten',

	'membershiptier:gadget:action:group:add'       => 'Aktion | Gruppe hinzuf�gen',
	'membershiptier:gadget:action:post:comment'    => 'Aktion | Kommentar',
	'membershiptier:gadget:action:post:like'       => 'Aktion | Reaktionen',
	'membershiptier:gadget:action:message:send'    => 'Aktion | Nachricht senden',
	'membershiptier:gadget:action:friend:add'      => 'Aktion | Freund hinzuf�gen',
	'membershiptier:gadget:action:forum:topic:add' => 'Aktion | Forumthema erstellen',
	'membershiptier:gadget:action:forum:reply:add' => 'Aktion | Forumantwort erstellen',
	'membershiptier:gadget:action:wall:post:a'     => 'Aktion | Beitrag im Newsfeed erstellen',
	'membershiptier:gadget:action:wall:post:u'     => 'Aktion | Beitrag auf Benutzerwand erstellen',
	'membershiptier:gadget:action:wall:post:g'     => 'Aktion | Beitrag auf Gruppenwand erstellen',
	'membershiptier:gadget:page:invite'            => 'Seite | Einladen',
	'membershiptier:gadget:page:group:guid'        => 'Seite | Gruppe ansehen',
	'membershiptier:gadget:page:group:guid:edit'   => 'Seite | Gruppe bearbeiten',
	'membershiptier:gadget:page:group:guid:members'=> 'Seite | Gruppenmitglieder',
	'membershiptier:gadget:page:messages:all'      => 'Seite | Nachrichten',
	'membershiptier:gadget:page:u:username:photos' => 'Seite | Fotos',
	'membershiptier:gadget:page:search'            => 'Seite | Suche',
	'membershiptier:gadget:page:page:all'          => 'Seite | Unternehmensseitenliste',
	'membershiptier:gadget:page:page:view:guid'    => 'Seite | Unternehmensseite anzeigen',
	'membershiptier:gadget:page:u:username'        => 'Seite | Benutzerprofil anzeigen',
	'membershiptier:gadget:page:profileviews'      => 'Seite | Wer hat das Profil angesehen',
	'membershiptier:gadget:page:video:add'         => 'Seite | Video hinzuf�gen',
	'membershiptier:gadget:page:video:all'         => 'Seite | Videoliste',
	'membershiptier:gadget:page:event:add'         => 'Seite | Veranstaltung hinzuf�gen',
	'membershiptier:gadget:page:poll:add'          => 'Seite | Umfrage hinzuf�gen',
	'membershiptier:gadget:page:poll:all'          => 'Seite | Umfrageliste',
	'membershiptier:gadget:page:files:add'         => 'Seite | Datei hinzuf�gen',
	'membershiptier:gadget:page:files:all'         => 'Seite | Dateiliste',
	'membershiptier:gadget:page:marketplace:add'   => 'Seite | Produkt auf Marktplatz hinzuf�gen',
	'membershiptier:gadget:page:marketplace:list'  => 'Seite | Marktplatzliste',
	'membershiptier:gadget:page:mp3:add'           => 'Seite | Audio hinzuf�gen',
	'membershiptier:gadget:page:mp3:all'           => 'Seite | Audioliste',
	'membershiptier:gadget:page:mp3:all:guid'      => 'Seite | Benutzeraudioliste',
	'membershiptier:gadget:page:whoisonline'       => 'Seite | Wer ist online',

	'membershiptier:title'                         => 'Stufenname/Titel',
	'membershiptier:cost'                          => 'Kosten der Stufe',
	'membershiptier:text'                          => 'Sie k�nnen im n�chsten Schritt die erlaubten Aktionen f�r jede Stufe ausw�hlen.',
	'membershiptier:duration'                      => 'Dauer',
	'membershiptier:duration:monthly'              => 'Monatlich',
	'membershiptier:duration:onetime'             => 'Einmalig',
	'membershiptier:brief:desc'                    => 'Beschreibung',
	'membershiptier:tieradd:failed'                => 'Hinzuf�gen der Stufe fehlgeschlagen. Bitte alle Felder ausf�llen.',
	'membershiptier:manageaccess'                  => 'Zugriffsrechte verwalten',
	'membershiptier:edit'                          => 'Stufe bearbeiten',
	'membershiptier:delete'                        => 'L�schen',
	'membershiptier:unabletoedit'                  => 'Stufe konnte nicht bearbeitet werden, bitte erneut versuchen!',
	'membershiptier:edited'                        => 'Stufe wurde bearbeitet',

	'membershiptier:list'                          => 'Stufenliste',
	'membershiptier:logs'                          => 'Zahlungsprotokolle',
	'membershiptier:add'                           => 'Stufe hinzuf�gen',
	'membershiptier:members:count'                => 'Mitglieder verwenden',
	'membershiptier:configure'                     => 'Konfigurieren',
	'membershiptier:cron:text'                     => 'Sie m�ssen CRON-Jobs konfigurieren, damit Ihre Mitgliedschaftsstufe funktioniert.',

	'membershiptier:type:page'                     => 'Seite',
	'membershiptier:type:action'                   => 'Aktion',
	'membershiptier:deleted'                       => 'Stufe wurde gel�scht!',
	'membershiptier:delete:failed'                 => 'L�schen der Stufe fehlgeschlagen',

	'membershiptier:pricing'                       => 'Mitgliedschaftspreise',
	'membershiptier:subcribe'                      => 'Abonnieren',
	'tier:subscribed:done'                         => 'Sie haben erfolgreich abonniert!',
	'tier:subscribe:failed'                        => 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es sp�ter erneut oder wenden Sie sich an den Administrator!',
	'membershiptier:pricing:heading'               => 'Um eine reibungslose Nutzung zu gew�hrleisten, stellen Sie bitte sicher, dass ausreichend Guthaben in Ihrem Wallet vorhanden ist. Optional k�nnen Sie eine Zahlungskarte hinterlegen, damit automatische Zahlungen reibungslos funktionieren.',

	'membershiptier:add:funds'                     => 'Guthaben hinzuf�gen',
	'membershiptier:status'                        => 'Mitgliedschaftsdetails',
	'membership:terminate:warning'                 => 'Diese Aktion ist unwiderruflich. M�chten Sie wirklich k�ndigen?',
	'membership:status'                            => 'Mitgliedschaftsstatus',
	'membership:status:subtext'                    => 'Willkommen auf Ihrer Mitgliedschafts�bersichtsseite. Hier finden Sie alle relevanten Informationen zu Ihrer Mitgliedschaft.',

	'membership:status:plan'                       => 'Planname',
	'membershiptier:duedate'                       => 'F�lligkeitsdatum',
	'membershiptier:canceltext'                    => 'Wir verstehen, dass sich Umst�nde �ndern k�nnen. Die K�ndigung Ihrer Mitgliedschaft ist einfach und es fallen keine Geb�hren an. Ihr Zugang zu bezahlten Funktionen wird beendet.',

	'membershiptier:cancel:now'                    => 'Jetzt k�ndigen',
	'membershiptier:nostatus'                      => '<p>Wir haben derzeit keine aktiven Abonnements f�r Ihr Konto.</p>

<p><strong>Abonnement abgelaufen:</strong> Ihr vorheriges Abonnement ist abgelaufen und wurde nicht erneuert. Bitte erneuern Sie es, um weiterhin unsere Dienste nutzen zu k�nnen.</p>

<p><strong>Abonnement gek�ndigt:</strong> Falls Sie ein aktives Abonnement hatten, das Sie gek�ndigt haben, werden die Details nicht mehr angezeigt. Sie k�nnen sich jedoch jederzeit erneut anmelden.</p>

<p><strong>Neues Konto oder keine Historie:</strong> Wenn Sie neu sind, haben Sie m�glicherweise noch keinen Plan abonniert. Diese Seite bleibt leer, bis Sie ein Abonnement starten.</p>',

	'membershiptier:plans'                          => 'Pl�ne ansehen',
	'membershiptier:needs:sub'                      => 'Sie m�ssen sich f�r diesen Plan anmelden, um die Seite zu sehen!',
	'membershiptier:success:charge:cron'            => 'Mitgliedschaft erfolgreich erneuert!',
	'membershiptier:success:charge:cron:msg'        => "Lieber %s,


Herzlichen Gl�ckwunsch! Ihre Mitgliedschaft wurde erfolgreich erneuert. Sie k�nnen weiterhin alle Vorteile nutzen, ohne Unterbrechung.

Vielen Dank f�r Ihr Vertrauen.
%s
%s",

	'membershiptier:failed:charge:cron'             => 'Mitgliedschaftserneuerung fehlgeschlagen!',
	'membershiptier:failed:charge:cron:msg'         => "Lieber %s,

Ihre Mitgliedschaft konnte nicht erneuert werden. �berpr�fen Sie Ihre Zahlungsdaten und Ihr Wallet-Guthaben. Bei Problemen wenden Sie sich bitte an den Support.

Danke!",
	'membershiptier:current:date'                   => 'Systemdatum & -zeit',
	'membershiptier:expiry:never'                  => 'Nie',
	'membershiptier:delete:text'                   => 'Wenn Sie diese Stufe l�schen, verlieren alle Benutzer dieser Stufe ihre Mitgliedschaft.',
	'membershiptier:members:export'                => 'Mitglieder exportieren',
	'membershiptier:subscribed'                     => 'Abonniert',
	'membershiptier:force:cards'                   => 'Automatische Zahlungen erzwingen',
	'membershiptier:force:cards:p'                 => 'Wenn aktiviert, m�ssen Benutzer beim Abonnement eine Karte hinterlegen. Andernfalls k�nnen sie sp�ter eine Karte speichern oder manuell Guthaben hinzuf�gen.',
	'membershiptier:force:disabled'                => 'Deaktiviert',
	'membershiptier:force:enabled'                 => 'Aktiviert',
	'membershiptier:addusertotier'                 => 'Benutzer zur Stufe hinzuf�gen',
	'membershiptier:attachuser:note'               => 'Sie k�nnen einem Benutzer manuell eine Stufe zuweisen, nachdem Sie Guthaben auf sein Wallet geladen haben.',
	'membershiptier:searchuser'                    => 'Benutzer suchen (E-Mail)',
	'membershiptier:searchuser:next'               => 'Weiter',
	'membershiptier:searchuser:invalid'            => 'Kein solcher Benutzer!',
	'membershiptier:searchuser:noadmin'            => 'Admins k�nnen nicht zu einer Stufe hinzugef�gt werden!',
	'membershiptier:searchuser:already'            => 'Dieser Benutzer hat bereits eine aktive Stufe.',
	'tier:manualattach:failed'                     => 'Benutzer konnte nicht zur Stufe hinzugef�gt werden!',
	'membershiptier:users:list'                    => 'Benutzer',
	'tier:manualattach:done'                       => 'Benutzer zur Stufe hinzugef�gt!',
	'membershiptier:date:format'                   => 'Datumsformat',
	'membershiptier:duration:yearly'               => 'J�hrlich',
));