<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'com:rememberlogin:keep:login' => 'Mich eingeloggt halten', 
));