<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team https://www.openteknik.com/contact
 * @copyright 2014-2016 OPENTEKNIK LLC
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$de = array(
	'forum' => 'Forum',
	'forum:cat:add' => 'Kategorie hinzuf�gen',
	'forum:category:title' => 'Titel',
	'forum:category:description' => 'Beschreibung',
	'forum:cat:added' => 'Die Forumskategorie wurde hinzugef�gt',
	'forum:cat:add:failed' => 'Die Forumskategorie konnte nicht hinzugef�gt werden',
	'forum:select:category' => 'Kategorie ausw�hlen',
	'forum:topic:add' => 'Thema hinzuf�gen',
	
	'forum:topic:title' => 'Einen passenden Thementitel hinzuf�gen',
	'forum:topic:description' => 'Details zum Thema hinzuf�gen',
	
	'forum:topic:added' => 'Das Forenthema wurde hinzugef�gt',
	'forum:topic:add:failed' => 'Das Forenthema konnte nicht hinzugef�gt werden',
	
	'forum:cat:edit' => 'Bearbeiten',
	'forum:cat:edited' => 'Die Kategorie wurde bearbeitet',
	'forum:cat:edit:failed' => 'Die Kategorie konnte nicht bearbeitet werden',
	
	'forum:categories' => 'Kategorien',
	
	'forum:cat:deleted' => 'Die Kategorie wurde gel�scht',
	'forum:cat:delete:failed' => 'Die Kategorie konnte nicht gel�scht werden',
	'forum:topic:edit' => 'Thema bearbeiten',
	
	'forum:topic:edit:failed' => 'Die Bearbeitung des Themas ist fehlgeschlagen',
	'forum:topic::edited' => 'Das Thema wurde bearbeitet',
	
	'forum:topic:delete:failed' => 'Das Thema konnte nicht gel�scht werden',
	'forum:topic:deleted' => 'Das Thema wurde gel�scht',
	'forum:reply:button' => 'Antworten',
	
	'forum:reply' => 'AW: %s',
	'forum:reply:edit' => 'Antwort bearbeiten',
	
	'forum:topic:reply:edited' => 'Die Antwort wurde bearbeitet',
	'forum:topic:reply:edit:failed' => 'Die Bearbeitung der Antwort ist fehlgeschlagen',
	
	'forum:topic:reply:delete:failed' => 'Die Antwort konnte nicht gel�scht werden',
	'forum:topic:reply:deleted' => 'Die Antwort wurde gel�scht',
	
	'forum:save' => 'Speichern',
	
	'forum:total:topics' => 'Themen insgesamt',
	'forum:total:last:topic' => 'Letztes Thema',
	
	'forum:topics' => 'Themen',
	'forum:total:topics' => 'Antworten insgesamt',
	'forum:total:last:reply' => 'Letzte Antwort',
	
	'forum:topic:reply:failed' => 'Antwort konnte nicht hinzugef�gt werden',
	'forum:topic:reply:added' => 'Antwort wurde hinzugef�gt',
	'ossn:notifications:forum:topic:reply' => '%s hat auf das Thema <strong>%s</strong> geantwortet',	
	
	'forum:add:cat' => 'Kategorie hinzuf�gen',
	'forum:quote' => 'Antwort zitieren',
	
	'forum:topic:search' => 'Forenthema',
	'forum:topic:wall:added' => 'hat ein neues Forenthema hinzugef�gt %s',
	'forum:topic:reply:wall:added' => 'hat eine Antwort zum Forenthema hinzugef�gt %s',
	'forum:readmore' => 'Mehr lesen',
);
ossn_register_languages('de', $de);