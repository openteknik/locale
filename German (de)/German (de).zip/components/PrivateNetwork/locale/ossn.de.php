<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'com:private:network:deney' => 'Sie müssen sich anmelden, bevor Sie diese Seite anzeigen.', 
));