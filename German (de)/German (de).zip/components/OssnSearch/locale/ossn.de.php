<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'ossn:search' => 'Suchen', 
	 'result:type' => 'ERGEBNIS-TYP', 
	 'search:result' => 'Suchergebnisse für %s', 
	 'ossn:search:topbar:search' => 'Suchgruppen, Freunde und mehr.', 
	 'ossn:search:no:result' => 'Keine Ergebnisse gefunden!', 
));