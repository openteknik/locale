<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'ossnsitepages' => 'Seiten-Seiten', 
	 'site:privacy' => 'Datenschutz', 
	 'site:about' => 'Informationen zu', 
	 'site:terms' => 'Vertragsbedingungen', 
	 'page:saved' => 'Seite erfolgreich gespeichert!', 
	 'page:save:error' => 'Seite kann nicht gespeichert werden! Versuchen Sie es später erneut.', 
));