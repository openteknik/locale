<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'mail:notfication:subject' => 'Sie haben eine neue Benachrichtigung!', 
	 'email:notfication:main:body' => 'Hallo %s, 

%s

%s

%s %s', 
	 'emailnotifications' => 'E-Mail-Benachrichtigungen', 
	 'notification:type:comments:entity:file:profile:photo' => 'Kommentar zu Profil-Foto', 
	 'notification:type:like:post:group:wall' => 'Group Wall Post Like', 
	 'notification:type:like:post' => 'Wall Post Like', 
	 'notification:type:comments:post' => 'Postkommentar', 
	 'notification:type:comments:post:group:wall' => 'Gruppe Wall Post Kommentar', 
	 'notification:type:group:joinrequest' => 'Gruppenverknüpfungsanfrage', 
	 'notification:type:like:annotation' => 'Kommentar wie', 
	 'notification:type:comments:entity:file:ossn:aphoto' => 'Album Photo Kommentar', 
	 'notification:type:ossnpoke:poke' => 'Poke', 
	 'notification:type:wall:friends:tag' => 'Tagged in wall post', 
));