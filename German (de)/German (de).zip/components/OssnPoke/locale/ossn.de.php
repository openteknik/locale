<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'ossn:notifications:ossnpoke:poke' => '%s hat Sie gepokt!', 
	 'user:poked' => 'Sie haben %s gepokt!', 
	 'user:poke:error' => 'Poke %s nicht möglich! Versuchen Sie es später erneut.', 
	 'poke' => 'Poke', 
));