<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'multiupload:text' => 'Bitte geben Sie den Text für Ihren Wandpfosten ein!', 
));