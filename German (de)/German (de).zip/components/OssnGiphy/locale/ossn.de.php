<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'ossngiphy' => 'Giphy', 
	 'ossngiphy:powered' => 'Powered by GIPHY', 
));