<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'firstlogin' => 'Erste Anmeldung', 
	 'first:login:url' => 'Geben Sie die URL ein', 
	 'first:login:placeholder' => 'https://mysiteurl.com/[USERNAME]', 
	 'firstlogin:saved' => 'Gespeicherte Einstellungen', 
	 'firstlogin:cannot:save' => 'Die Einstellungen können nicht gespeichert werden.', 
	 'first:login:info' => 'Im Folgenden sind die Tags aufgeführt, die Sie in der URL verwenden können, <br /> [BENUTZERNAME] ist der Benutzername des Benutzers, der angemeldet ist.<br /> [GUID] ist die ID für den Benutzer mit dem Namen \"loggedin\".', 
));