<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'ossnlocation' => 'OssnLocation', 
	 'enter:location' => 'Position eingeben', 
));