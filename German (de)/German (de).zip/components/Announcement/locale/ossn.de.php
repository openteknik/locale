<?php
/**
* Translated locale
* ossn.de.php
**/

ossn_register_languages('de', array(
	 'announcement' => 'Site-Ankündigung', 
	 'announcement:title' => 'Ankündigung!', 
	 'announcement:save:error' => 'Die Ankündigung konnte nicht gespeichert werden.', 
	 'announcement:saved' => 'Die Ankündigung wurde gespeichert.', 
	 'announcement:text' => 'Geben Sie Ihre Ankündigung ein', 
));