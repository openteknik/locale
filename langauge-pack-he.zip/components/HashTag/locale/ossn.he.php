<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'hashtag:trending' => 'טרנד', 
	 'hashtag:counter' => 'עמדות קיר של %s', 
));