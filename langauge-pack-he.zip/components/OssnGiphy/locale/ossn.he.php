<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'ossngiphy' => 'גיפי', 
	 'ossngiphy:powered' => 'מופעל על-ידי GIPHY', 
));