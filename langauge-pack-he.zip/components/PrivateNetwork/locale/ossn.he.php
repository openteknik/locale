<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'com:private:network:deney' => 'אתם נדרשים להתחבר לפני הצגת הדף.', 
));