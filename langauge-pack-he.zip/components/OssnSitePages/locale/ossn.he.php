<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'ossnsitepages' => 'דפי אתר', 
	 'site:privacy' => 'פרטיות', 
	 'site:about' => 'אודות', 
	 'site:terms' => 'תנאים והתניות', 
	 'page:saved' => 'הדף נשמר בהצלחה!', 
	 'page:save:error' => 'לא ניתן לשמור את הדף! נא לנסות שוב מאוחר יותר.', 
));