<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'multiupload:text' => 'נא לציין את התמליל עבור עמוד הקיר שלכם!', 
));