<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'mobilelogin' => 'נייד', 
	 'mobilelogin:username' => 'שם משתמש/דואל/נייד', 
	 'mobilelogin:invalid:mobile' => 'מספר נייד לא חוקי', 
	 'mobilelogin:num' => '+1245678910', 
	 'mobilelogin:mobile:exists' => 'מספר נייד כבר נמצא בשימוש', 
));