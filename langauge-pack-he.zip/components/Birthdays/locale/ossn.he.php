<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'birthdays:upcoming' => 'ימי הולדת המתקרבים', 
	 'birthdays:on' => '%s יום הולדת ב - %d', 
	 'birthdays:nobirthday' => 'אין ימי הולדת קרובים!', 
));