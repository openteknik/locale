<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'passwordvalidation:atleast' => 'להיות לפחות <em>%s<em> תווים ארוכים', 
	 'passwordvalidation:passwordmustbe' => 'הסיסמה שלכם חייבת:', 
	 'passwordvalidation:capitalletter' => 'מכיל מכתב הון', 
	 'passwordvalidation:lowerletter' => 'מכיל אות מקרה נמוך יותר', 
	 'passwordvalidation:number' => 'מכיל מספר', 
	 'passwordvalidation:error' => 'סיסמה זו אינה עונה על הדרישות.', 
));