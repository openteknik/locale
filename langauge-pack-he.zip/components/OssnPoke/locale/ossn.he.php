<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'ossn:notifications:ossnpoke:poke' => '%s דקר אתכם!', 
	 'user:poked' => 'יש לכם poked %s!', 
	 'user:poke:error' => 'לא ניתן לתקוע את %s! נא לנסות שוב מאוחר יותר.', 
	 'poke' => 'פוק', 
));