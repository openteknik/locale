<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'hangout' => 'שיחת אודיו/וידיאו', 
));