<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'accesscode' => 'קוד גישה', 
	 'accesscode:saved' => 'קוד הגישה נשמר.', 
	 'accesscode:save:error' => 'לא ניתן לשמור את קוד הגישה.', 
	 'accesscode:register:code' => 'קוד גישה/קוד Signup', 
	 'access:code:error' => 'קוד גישה לא חוקי', 
));