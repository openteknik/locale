<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'groupinvite:widget:title' => 'הזמנת חבר', 
	 'groupinvite:widget:desc' => 'בחרו את החברים שלכם מופרדים בפסיקים ולחצו על משלוח.', 
	 'groupinvite:invite' => 'הזמנה', 
	 'groupinvite:sent' => 'ההזמנה נשלחה, החבר שלכם יקבל פרסום על הזמנתכם', 
	 'ossn:notifications:groupinvite' => '%s הזמין אתכם להצטרף לקבוצה <strong>%s</strong>', 
));