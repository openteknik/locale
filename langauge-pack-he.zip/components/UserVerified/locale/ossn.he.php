<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'userverified:success' => 'אומת בהצלחה', 
	 'userverified:failed' => 'האימות נכשל', 
	 'userverified:verified' => 'פרופיל מאומת', 
	 'userverified:verify' => 'אימות', 
	 'userverified:unverify' => 'ביטול אימות', 
	 'userverified:unverifiy:success' => 'לא אומת בהצלחה', 
	 'userverified:unverifiy:failed' => 'לא מאומת נכשל', 
));