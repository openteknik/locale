<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'people:like:this' => 'אנשים שהגיב לזה!', 
	 'ossn:like:this' => '%s הגיב על זה', 
	 'ossn:like:you:and:this' => 'אתם ו - %s הגיבו על פריט זה', 
	 'ossn:like:people' => '%s אנשים', 
	 'ossn:like:person' => 'אדם %s', 
	 'ossn:liked:you' => 'הגבת על זה.', 
	 'ossn:unlike' => 'שלא כמו', 
	 'ossn:like' => 'כמו', 
));