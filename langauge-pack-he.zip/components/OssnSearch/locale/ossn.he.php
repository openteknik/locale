<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'ossn:search' => 'חיפוש', 
	 'result:type' => 'סוג תוצאה', 
	 'search:result' => 'תוצאות חיפוש עבור %s', 
	 'ossn:search:topbar:search' => 'קבוצות חיפוש, חברים ועוד.', 
	 'ossn:search:no:result' => 'לא נמצאו תוצאות!', 
));