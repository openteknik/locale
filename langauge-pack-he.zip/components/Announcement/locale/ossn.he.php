<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'announcement' => 'הכרזה באתר', 
	 'announcement:title' => 'הכרזה!', 
	 'announcement:save:error' => 'לא ניתן לשמור את ההודעה.', 
	 'announcement:saved' => 'ההודעה נשמרה', 
	 'announcement:text' => 'ציינו את הודעת ההודעה שלכם.', 
));