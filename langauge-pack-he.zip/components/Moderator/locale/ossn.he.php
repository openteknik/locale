<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'moderator' => 'מנחה', 
	 'can_moderate' => 'המשתמש יכול לפקח על פרסומים, הערות, תמונות, קבוצות', 
	 'delete:cover' => 'מחיקת כיסוי', 
	 'moderator:yes' => 'כן', 
	 'moderator:no' => 'לא', 
	 'moderate:users' => 'משתמשים בפיקוח', 
	 'moderator:delete:user' => 'מחיקת משתמש', 
	 'moderator:select' => 'נא לבחור.', 
));