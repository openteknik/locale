<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'userstats:friends' => 'חברים', 
	 'userstats:comments' => 'הערות', 
	 'userstats:reactions' => 'ריכויים', 
	 'userstats:posts' => 'פרסומים', 
));