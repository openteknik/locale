<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'banuser:unban' => 'משתמש Unban', 
	 'banuser' => 'משתמש Ban', 
	 'banuser:invalid:user' => 'משתמש לא חוקי', 
	 'banuser:banned' => 'המשתמש נאסר בהצלחה', 
	 'banuser:ban:failed' => 'איסור המשתמש נכשל.', 
	 'banuser:unbanned' => 'המשתמש בוטל בהצלחה', 
	 'banuser:unban:failed' => 'ביטול המשתמש נכשל', 
	 'banuser:notice' => 'משתמש זה נאסר באתר זה על הפרת תנאי האתר.', 
	 'banuser:banned:login' => 'נאסר עליך להיכנס לאתר הזה.', 
));