<?php
/**
* Translated locale
* ossn.he.php
**/

ossn_register_languages('he', array(
	 'goblue:settings' => 'כחול', 
	 'admin:theme:goblue' => 'כחול', 
	 'theme:goblue:logo:site' => 'לוגו אתר', 
	 'theme:goblue:logo:admin' => 'לוגו של מנהלן', 
	 'theme:goblue:logo:large' => 'קובץ הלוגו גדול מדי!', 
	 'theme:goblue:logo:failed' => 'טעינת ההעלאה נכשלה', 
	 'theme:goblue:logo:changed' => 'לוגו השתנה.', 
	 'theme:goblue:browercache' => 'במקרה של תמונות לא יופיעו. נקו את מטמון הדפדפן כדי להציג את התמונות.', 
));