<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'goblue:settings' => 'GoMavisi', 
	 'admin:theme:goblue' => 'GoMavisi', 
	 'theme:goblue:logo:site' => 'Site Logosu', 
	 'theme:goblue:logo:admin' => 'Yönetici Logosu', 
	 'theme:goblue:logo:large' => 'Logo dosyası çok büyük!', 
	 'theme:goblue:logo:failed' => 'Logo karşıya yükleme başarısız oldu', 
	 'theme:goblue:logo:changed' => 'Logo değiştirildi.', 
	 'theme:goblue:browercache' => 'Vaka görüntüleri görüntülenmezse. Görüntülerin görünmesini sağlamak için lütfen web tarayıcınızın önbelleğinizi temizleyin', 
));