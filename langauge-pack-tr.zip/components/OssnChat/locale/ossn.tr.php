<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'ossn:chat:no:friend:online' => 'Çevrimiçi arkadaş yok', 
));