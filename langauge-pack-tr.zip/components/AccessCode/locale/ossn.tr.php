<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'accesscode' => 'Erişim Kodu', 
	 'accesscode:saved' => 'Erişim kodu kaydedildi.', 
	 'accesscode:save:error' => 'Erişim kodu saklanabilir', 
	 'accesscode:register:code' => 'Accesscode/Signup Kodu', 
	 'access:code:error' => 'Erişim Kodu Geçersiz', 
));