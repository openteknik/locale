<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'ossnsitepages' => 'Site Sayfaları', 
	 'site:privacy' => 'Gizlilik', 
	 'site:about' => 'Hakkında', 
	 'site:terms' => 'Kayıt ve Koşullar', 
	 'page:saved' => 'Sayfa başarıyla saklandı!', 
	 'page:save:error' => 'Sayfa saklanamıyor! Lütfen daha sonra yeniden deneyin.', 
));