<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'people:like:this' => 'Buna tepki veren insanlar!', 
	 'ossn:like:this' => '%s bu konuda tepki gösterdi', 
	 'ossn:like:you:and:this' => 'Siz ve %s bu konuda tepki gösterdiniz', 
	 'ossn:like:people' => '%s Kişi', 
	 'ossn:like:person' => '%s Kişi', 
	 'ossn:liked:you' => 'Buna tepki gösterdin.', 
	 'ossn:unlike' => 'Tersine', 
	 'ossn:like' => 'Benzer', 
));