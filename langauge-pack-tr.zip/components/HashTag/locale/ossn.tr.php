<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'hashtag:trending' => 'Eğilim', 
	 'hashtag:counter' => '%s duvar gönderileri', 
));