<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'announcement' => 'Site Duyuru', 
	 'announcement:title' => 'Duyuru!', 
	 'announcement:save:error' => 'Duyuru saklanamadı', 
	 'announcement:saved' => 'Duyuru kaydedildi', 
	 'announcement:text' => 'Duyuru iletinizi girin', 
));