<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'moderator' => 'Toplantı Başkanı Yap', 
	 'can_moderate' => 'Kullanıcı postaları, yorumları, fotoğrafları, grupları denetleyebilir', 
	 'delete:cover' => 'Kapağı Sil', 
	 'moderator:yes' => 'Evet', 
	 'moderator:no' => 'Hayır', 
	 'moderate:users' => 'Orta Düzey Kullanıcılar', 
	 'moderator:delete:user' => 'Kullanıcıyı Sil', 
	 'moderator:select' => 'Lütfen seçin', 
));