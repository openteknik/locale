<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'siteoffline' => 'Site Çevrimdışı', 
	 'siteoffline:online' => 'Çevrimiçi', 
	 'siteoffline:offline' => 'Çevrimdışı', 
	 'siteoffline:save:error' => 'Ayarlar saklanmayabilir', 
	 'siteoffline:saved' => 'Ayarlar saklandı', 
	 'siteoffline:login' => 'Site yöneticisi oturum açma', 
	 'siteoffline:login:error' => 'Yalnızca yönetici oturum açma işlemine izin verilir', 
	 'siteoffline:message' => 'Üzgünüz, sitemizin geçici olarak bakım için aşağısı var. Lütfen tekrar tekrar kontrol edin.', 
));