<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'passwordvalidation:atleast' => 'en az <em>%s<em> karakter uzunluğunda olmalıdır', 
	 'passwordvalidation:passwordmustbe' => 'Parolanınız şu şekilde olmalıdır:', 
	 'passwordvalidation:capitalletter' => 'bir sermaye mektubu içerir', 
	 'passwordvalidation:lowerletter' => 'küçük harfli bir harf içerir', 
	 'passwordvalidation:number' => 'bir sayı içerir', 
	 'passwordvalidation:error' => 'Bu parola gereklilikleri karşılamıyor', 
));