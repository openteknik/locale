<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'mobilelogin' => 'Mobil', 
	 'mobilelogin:username' => 'Kullanıcı Adı/E-posta/Mobil', 
	 'mobilelogin:invalid:mobile' => 'Geçersiz Mobil Numara', 
	 'mobilelogin:num' => '+1245678910', 
	 'mobilelogin:mobile:exists' => 'Bir cep telefonu numarası zaten kullanımda', 
));