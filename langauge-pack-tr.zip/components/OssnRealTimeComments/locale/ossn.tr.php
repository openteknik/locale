<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'rtcomments:typing' => 'Birisi bir yorum yazıyor ...', 
));