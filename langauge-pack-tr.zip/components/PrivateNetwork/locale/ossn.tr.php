<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'com:private:network:deney' => 'Bu sayfayı görüntülemeden önce oturum açmanız gerekli', 
));