<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'ossngiphy' => 'Giphy', 
	 'ossngiphy:powered' => 'Powered by GIphy', 
));