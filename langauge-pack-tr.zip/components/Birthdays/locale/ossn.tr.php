<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'birthdays:upcoming' => 'Yaklaşan doğum günleri', 
	 'birthdays:on' => '%s %d gününde doğum günü içeriyor', 
	 'birthdays:nobirthday' => 'Yaklaşan doğum günü yok!', 
));