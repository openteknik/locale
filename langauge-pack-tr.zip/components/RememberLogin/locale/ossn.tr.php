<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'com:rememberlogin:keep:login' => 'Oturum açmama devam et', 
));