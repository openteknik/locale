<?php
/**
* Translated locale
* ossn.tr.php
**/

ossn_register_languages('tr', array(
	 'gdpr:deleteaccount' => 'Hesabı Sil', 
	 'gdpr:account:deleted' => 'Hesabınız silindi', 
	 'gdpr:account:delete:error' => 'Hesabınız silinemiyor', 
	 'gdpr:confirm:signup' => '%s web sitenize ve %s web sitenize kabul etmeyi onaylıyorum', 
	 'gdpr:privacypolicy' => 'Gizlilik İlkesi', 
	 'gdpr:signup:error' => 'Web sitemize ilişkin Kayıt ve Gizlilik İlkesiyle aynı fikirde olduğunu onaylamanız gerekir', 
	 'gdpr:delete:account:notice' => 'Uyarı! Hesap silme işlemi kalıcı olacak. Bu işlem geri alınamaz.', 
));