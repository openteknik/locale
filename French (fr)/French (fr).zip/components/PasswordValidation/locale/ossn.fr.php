<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'passwordvalidation:atleast' => 'être au moins <em>%s<em> caractères long', 
	 'passwordvalidation:passwordmustbe' => 'Votre mot de passe doit:', 
	 'passwordvalidation:capitalletter' => 'Contenir une lettre majusque', 
	 'passwordvalidation:lowerletter' => 'Contenir une lettre de dossier inférieure', 
	 'passwordvalidation:number' => 'Contenir un nombre', 
	 'passwordvalidation:error' => 'Ce mot de passe ne répond pas aux exigences', 
));