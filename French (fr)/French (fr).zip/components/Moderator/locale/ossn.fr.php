<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'moderator' => 'Créer un modÚrateur', 
	 'can_moderate' => 'L\'utilisateur peut modérer les messages, commentaires, photos, groupes', 
	 'delete:cover' => 'Supprimer la couverture', 
	 'moderator:yes' => 'Oui', 
	 'moderator:no' => 'Non', 
	 'moderate:users' => 'Utilisateurs modérés', 
	 'moderator:delete:user' => 'Supprimer un utilisateur', 
	 'moderator:select' => 'Veuillez sélectionner', 
));