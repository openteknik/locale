<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'ossnsitepages' => 'Pages de site', 
	 'site:privacy' => 'Confidentialité', 
	 'site:about' => 'A propos', 
	 'site:terms' => 'Termes et conditions', 
	 'page:saved' => 'Page sauvegardée avec succès !', 
	 'page:save:error' => 'Impossible d\'enregistrer la page ! Veuillez réessayer ultérieurement.', 
));