<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'ossn:notifications:ossnpoke:poke' => '%s vous a souillé !', 
	 'user:poked' => 'Vous avez coché %s !', 
	 'user:poke:error' => 'Impossible de poke %s ! Veuillez réessayer ultérieurement.', 
	 'poke' => 'Poke', 
));