<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'accesscode' => 'Code d\'accès', 
	 'accesscode:saved' => 'Le code d\'accès a été sauvegardé.', 
	 'accesscode:save:error' => 'Impossible d\'enregistrer le code d\'accès', 
	 'accesscode:register:code' => 'Code d\'accès / Code d\'accès', 
	 'access:code:error' => 'Code d\'accès non valide', 
));