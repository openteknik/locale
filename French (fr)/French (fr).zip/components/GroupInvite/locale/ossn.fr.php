<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'groupinvite:widget:title' => 'Inviter un ami', 
	 'groupinvite:widget:desc' => 'Sélectionnez vos amis séparés par une virgule et cliquez sur envoyer.', 
	 'groupinvite:invite' => 'Inviter', 
	 'groupinvite:sent' => 'L\'invitation a été envoyée, votre ami recevra une notation de votre invitation', 
	 'ossn:notifications:groupinvite' => '%s vous a invité à rejoindre le groupe <strong>%s</strong>', 
));