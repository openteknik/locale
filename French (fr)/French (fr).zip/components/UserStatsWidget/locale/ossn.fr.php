<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'userstats:friends' => 'Amis', 
	 'userstats:comments' => 'Commentaires', 
	 'userstats:reactions' => 'Réactions', 
	 'userstats:posts' => 'Postes', 
));