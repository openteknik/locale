<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'ossn:search' => 'Rechercher', 
	 'result:type' => 'TYPE DE RÉSULTAT', 
	 'search:result' => 'Résultats de la recherche pour %s', 
	 'ossn:search:topbar:search' => 'Groupes de recherche, amis et plus.', 
	 'ossn:search:no:result' => 'Aucun résultat trouvé !', 
));