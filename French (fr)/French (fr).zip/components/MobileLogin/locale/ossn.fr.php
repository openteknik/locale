<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'mobilelogin' => 'Mobile', 
	 'mobilelogin:username' => 'Nom d\'utilisateur / Email / Mobile', 
	 'mobilelogin:invalid:mobile' => 'Numéro Mobile non valide', 
	 'mobilelogin:num' => '+1245678910', 
	 'mobilelogin:mobile:exists' => 'Un numéro de téléphone mobile est déjà utilisé', 
));