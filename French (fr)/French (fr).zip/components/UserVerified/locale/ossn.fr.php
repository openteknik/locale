<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'userverified:success' => 'Vérifié avec succès', 
	 'userverified:failed' => 'Echec de la vérification', 
	 'userverified:verified' => 'Profil vérifié', 
	 'userverified:verify' => 'Vérifier', 
	 'userverified:unverify' => 'Dévérifier', 
	 'userverified:unverifiy:success' => 'Non vérifié avec succès', 
	 'userverified:unverifiy:failed' => 'Echec non vérifié', 
));