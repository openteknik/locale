<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'com:rememberlogin:keep:login' => 'Garder-moi connecté', 
));