<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'multiupload:text' => 'Veuillez entrer le texte de votre poste de mur !', 
));