<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'ossngiphy' => 'Giphy', 
	 'ossngiphy:powered' => 'Propulsé par GIPHY', 
));