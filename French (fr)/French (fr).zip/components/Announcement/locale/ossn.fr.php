<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'announcement' => 'Annonce de site', 
	 'announcement:title' => 'Annonce !', 
	 'announcement:save:error' => 'L\'annonce n\'a pas pu être enregistrée', 
	 'announcement:saved' => 'L\'annonce a été enregistrée', 
	 'announcement:text' => 'Entrez votre message d\'annonce', 
));