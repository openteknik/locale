<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'ossn:chat:no:friend:online' => 'Aucun ami en ligne', 
));