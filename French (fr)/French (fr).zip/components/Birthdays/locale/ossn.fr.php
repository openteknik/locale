<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'birthdays:upcoming' => 'Jours d\'anniversaire à venir', 
	 'birthdays:on' => '%s fêtant son anniversaire sur %d', 
	 'birthdays:nobirthday' => 'Aucun anniversaire à venir !', 
));