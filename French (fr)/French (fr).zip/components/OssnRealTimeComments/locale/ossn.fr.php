<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'rtcomments:typing' => 'Quelqu\'un tape un commentaire ...', 
));