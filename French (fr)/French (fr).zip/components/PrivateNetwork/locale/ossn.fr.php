<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'com:private:network:deney' => 'Vous devez vous connecter avant d\'afficher cette page', 
));