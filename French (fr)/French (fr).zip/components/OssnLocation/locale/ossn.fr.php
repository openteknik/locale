<?php
/**
* Translated locale
* ossn.fr.php
**/

ossn_register_languages('fr', array(
	 'ossnlocation' => 'Emplacement OssnLocation', 
	 'enter:location' => 'Entrer l\'emplacement', 
));