<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'people:like:this' => 'Oameni care au reacționat la asta!', 
	 'ossn:like:this' => '%s a reacționat în acest sens', 
	 'ossn:like:you:and:this' => 'Tu și %s ați reacționat la asta', 
	 'ossn:like:people' => '%s Oameni', 
	 'ossn:like:person' => '%s Persoană', 
	 'ossn:liked:you' => 'Ai reacţionat la asta.', 
	 'ossn:unlike' => 'Spre deosebire', 
	 'ossn:like' => 'Like', 
));