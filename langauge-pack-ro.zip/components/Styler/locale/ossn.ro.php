<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'styler' => 'Styler', 
	 'styler:brown' => 'Maro', 
	 'styler:blue' => 'Albastru', 
	 'styler:darkyellow' => 'Galben închis', 
	 'styler:montego' => 'Montego', 
	 'styler:green' => 'Verde', 
	 'styler:pink' => 'Roz', 
	 'styler:red' => 'Roșu', 
	 'styler:select:color' => 'Selectați culoarea de mai jos', 
	 'styler:save:error' => 'Nu pot salva setările', 
	 'styler:saved' => 'Setările au fost salvate', 
));