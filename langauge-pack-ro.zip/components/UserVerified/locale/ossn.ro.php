<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'userverified:success' => 'Verificat cu succes', 
	 'userverified:failed' => 'Verificat a eșuat', 
	 'userverified:verified' => 'Profil verificat', 
	 'userverified:verify' => 'Verifică', 
	 'userverified:unverify' => 'Neverificarea', 
	 'userverified:unverifiy:success' => 'Neverificat cu succes', 
	 'userverified:unverifiy:failed' => 'Eșec neverificat', 
));