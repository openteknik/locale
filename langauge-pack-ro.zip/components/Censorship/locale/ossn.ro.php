<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'censorship' => 'Cenzură', 
	 'censorship:add:words' => 'Introduceți cuvintele de mai jos', 
	 'censorship:add:words:note' => 'Introduceți cuvintele seprated by a comma (,). Word1, Word2, Word3', 
	 'censorship:replace:string' => 'Introduceți șir pentru a înlocui cuvintele rele cu', 
	 'censorship:fields:error' => 'Toate câmpurile sunt obligatorii', 
	 'censorship:saved' => 'Setarea a fost salvată', 
	 'censorship:save:error' => 'Nu pot salva setările', 
));