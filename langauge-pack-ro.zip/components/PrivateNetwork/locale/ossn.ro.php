<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'com:private:network:deney' => 'Trebuie să vă conectați înainte de a vizualiza pagina respectivă', 
));