<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'post:share' => 'Share', 
	 'post:shared' => 'Post has been shared', 
	 'post:share:error' => 'Postul nu poate fi partajat', 
	 'post:shared:title' => 'Post comun', 
	 'post:share:unavailable' => 'Este posibil ca acest atașament să fi fost înlăturat sau persoana care a împărtășit-o să nu aibă permisiunea de a o împărtăși cu dvs.', 
	 'post:share:type' => 'Selectează tipul', 
	 'post:share:selectfriend' => 'Alege prieten', 
	 'post:share:selectgroup' => 'Selectare grup', 
	 'post:share:newsfeed' => 'Newsfeed', 
	 'post:share:friend' => 'Profilul prietenului', 
	 'post:share:group' => 'Grup', 
	 'post:shared:event:title' => 'Partajarea unui eveniment', 
	 'post:shared:poll:title' => 'Partajat un sondaj', 
	 'post:shared:video:title' => 'Partajat un video %s', 
	 'post:shared:file:title' => 'Partajat un fișier', 
	 'post:shared:marketplace:product' => 'Partajat un produs', 
	 'post:shared:from:group' => 'Partajat un post de la un grup', 
	 'post:shared:from:businesspage' => 'Partajat un mesaj de la o pagină', 
));