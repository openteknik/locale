<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'ossnads' => 'Manager de anunțuri', 
	 'fields:required' => 'Toate câmpurile sunt obligatorii!', 
	 'ad:created' => 'Ad a fost creat!', 
	 'ad:create:fail' => 'Nu pot crea reclame!', 
	 'ad:title' => 'Titlul', 
	 'ad:site:url' => 'Siteurl', 
	 'ad:desc' => 'Descriere', 
	 'ad:photo' => 'Foto', 
	 'ad:browse' => 'Navigați', 
	 'ad:clicks' => 'Clicuri', 
	 'sponsored' => 'SPONSORIZAT', 
	 'ad:deleted' => 'Ad with the title of \'%s\' has been successfully deleted.', 
	 'ad:delete:fail' => 'Nu se poate șterge anunțul! Încearcă din nou mai târziu.', 
	 'ad:edited' => 'Ad modificat cu succes.', 
	 'ad:edit:fail' => 'Nu pot edita reclama! Încearcă din nou mai târziu.', 
));