<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'bpage' => 'Pagina de afaceri', 
	 'bpage:cover:err1:detail' => 'Imaginea de acoperire trebuie să fie de cel puțin 850 x 300 sau mai mare.', 
	 'bpage:name' => 'Nume de pagină', 
	 'bpage:desc' => 'Descriere', 
	 'bpage:phone' => 'Telefon', 
	 'bpage:website' => 'Site', 
	 'bpage:address' => 'Adresă', 
	 'bpage:type' => 'Tip pagină', 
	 'bpage:change:photo' => 'Schimbă fotografia', 
	 'bpage:reposition' => 'Repoziționarea', 
	 'bpage:save:position' => 'Salvează poziția', 
	 'bpage:change:cover' => 'Schimbare de acoperire', 
	 'bpage:cat:business' => 'Afaceri', 
	 'bpage:cat:brand' => 'Brand', 
	 'bpage:cat:product' => 'Produs', 
	 'bpage:cat:artist' => 'Artist', 
	 'bpage:cat:public:figure' => 'Figura Publică', 
	 'bpage:cat:entertainment' => 'Divertisment', 
	 'bpage:cat:cause' => 'Cauză', 
	 'bpage:cat:community' => 'Comunitate', 
	 'bpage:cat:org' => 'Organizare', 
	 'bpage:edited' => 'Pagina a fost editat', 
	 'bpage:edit:failed' => 'Pagina nu poate fi editată', 
	 'bpage:deleted' => 'Pagina a fost ștearsă', 
	 'bpage:delete:failed' => 'Pagina nu poate fi ștearsă', 
	 'bpage:edit' => 'Editează pagina', 
	 'bpage:delete' => 'Șterge pagina', 
	 'bpage:list' => 'Toate paginile', 
	 'bpage:add' => 'Creează o nouă pagină', 
	 'bpage:cover:upload:error' => 'Nu se poate adăuga acoperire', 
	 'ossn:notifications:comments:post:businesspage:wall' => '%s a comentat pe pagina dvs. post', 
	 'ossn:notifications:like:post:businesspage:wall' => '%s liked your page post', 
	 'bpage:fileds:required' => 'Asigurați-vă că ați introdus numele, descrierea și categoria', 
	 'bpage:added' => 'Pagina a fost creată', 
	 'bpage:likedpages' => 'Pagini apreciate', 
	 'bpage:mypages' => 'Paginile mele', 
));