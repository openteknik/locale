<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'userstats:friends' => 'Prieteni', 
	 'userstats:comments' => 'Comentarii', 
	 'userstats:reactions' => 'Reacții', 
	 'userstats:posts' => 'Posturi', 
));