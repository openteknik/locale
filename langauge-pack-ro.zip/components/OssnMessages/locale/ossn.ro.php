<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'user:messages' => 'Mesaje', 
	 'inbox' => 'Inbox', 
	 'send' => 'Trimite', 
	 'ossn:message:between' => 'Mesaje %s', 
	 'messages' => 'Mesaje', 
	 'message:placeholder' => 'Introduceți textul aici', 
	 'no:messages' => 'Nu ai nici un mesaj.', 
	 'ossnmessages:deleted' => 'Mesajul a fost șters', 
	 'ossnmessages:delete:all' => 'Scoateți pentru toată lumea', 
	 'ossnmessages:delete:all:note' => 'Veți elimina definitiv acest mesaj pentru alt membru. Un alt membru va fi capabil să vadă că ai eliminat un mesaj.', 
	 'ossnmessages:delete:me' => 'Elimină pentru tine', 
	 'ossnmessages:delete:me:note' => 'Acest mesaj va fi eliminat pentru tine. Un alt membru va fi în stare să-l vadă.', 
	 'ossnmessages:replied:you' => 'Tu: %s', 
	 'message:fileattachment' => 'Atașament fișier', 
));