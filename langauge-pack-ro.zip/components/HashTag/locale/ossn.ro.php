<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'hashtag:trending' => 'Trending', 
	 'hashtag:counter' => '%s posturi de perete', 
));