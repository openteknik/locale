<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'album:name' => 'Nume album', 
	 'add:album' => 'Adaugă album', 
	 'photo:select' => 'Alege fotografia', 
	 'no:albums' => 'Fără Albume', 
	 'no:photos' => 'Nu există fotografii', 
	 'back:to:album' => 'Înapoi la album', 
	 'photo:albums' => 'Albume foto', 
	 'photo:deleted:success' => 'Fotografie șterse cu succes!', 
	 'photo:delete:error' => 'Nu se poate șterge fotografia! Încearcă din nou mai târziu.', 
	 'photos' => 'Fotografii', 
	 'back' => 'Înapoi.', 
	 'add:photos' => 'Adaugă fotografii', 
	 'delete:photo' => 'Șterge fotografia', 
	 'covers' => 'Capace', 
	 'cover:view' => 'Vizualizare copertă', 
	 'profile:covers' => 'Coperți de profil', 
	 'delete:album' => 'Șterge album', 
	 'photo:album:deleted' => 'Album foto șters cu succes', 
	 'photo:album:delete:error' => 'Nu se poate șterge album foto', 
));