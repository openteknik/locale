<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'passwordvalidation:atleast' => 'be at least <em>%s<em>', 
	 'passwordvalidation:passwordmustbe' => 'Parola dvs. trebuie:', 
	 'passwordvalidation:capitalletter' => 'conține o literă de capital', 
	 'passwordvalidation:lowerletter' => 'conțin o scrisoare de caz mai mică', 
	 'passwordvalidation:number' => 'conține un număr', 
	 'passwordvalidation:error' => 'Această parolă nu îndeplinește cerințele', 
));