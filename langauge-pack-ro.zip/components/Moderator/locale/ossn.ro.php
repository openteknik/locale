<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'moderator' => 'Face moderator', 
	 'can_moderate' => 'Utilizatorul poate modera posturi, comentarii, fotografii, grupuri', 
	 'delete:cover' => 'Șterge capacul', 
	 'moderator:yes' => 'Da.', 
	 'moderator:no' => 'Nr.', 
	 'moderate:users' => 'Utilizatori moderați', 
	 'moderator:delete:user' => 'Șterge utilizatorul', 
	 'moderator:select' => 'Vă rugăm selectați', 
));