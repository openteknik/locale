<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'ossnsitepages' => 'Pagini de site', 
	 'site:privacy' => 'Confidențialitate', 
	 'site:about' => 'Despre', 
	 'site:terms' => 'Termeni și condiții', 
	 'page:saved' => 'Pagina salvată cu succes!', 
	 'page:save:error' => 'Nu pot salva pagina! Încearcă din nou mai târziu.', 
));