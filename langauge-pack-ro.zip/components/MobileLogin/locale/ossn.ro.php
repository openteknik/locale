<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'mobilelogin' => 'Mobile', 
	 'mobilelogin:username' => 'Nume utilizator/Email/Mobile', 
	 'mobilelogin:invalid:mobile' => 'Număr Mobil nevalid', 
	 'mobilelogin:num' => '+1245678910', 
	 'mobilelogin:mobile:exists' => 'Un număr de telefon mobil este deja utilizat', 
));