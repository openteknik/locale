<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'accesscode' => 'Codul de acces', 
	 'accesscode:saved' => 'Codul de acces a fost salvat.', 
	 'accesscode:save:error' => 'Nu se poate salva codul de acces', 
	 'accesscode:register:code' => 'Cod de acces/cod de înregistrare', 
	 'access:code:error' => 'Cod de acces invalid', 
));