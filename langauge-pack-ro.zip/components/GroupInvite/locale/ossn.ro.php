<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'groupinvite:widget:title' => 'Invită un prieten', 
	 'groupinvite:widget:desc' => 'Selectați prietenii seperated de o virgulă și faceți clic pe trimite.', 
	 'groupinvite:invite' => 'Invitație', 
	 'groupinvite:sent' => 'Invitația a fost trimisă, prietenul tău va primi o notficare despre invitația ta', 
	 'ossn:notifications:groupinvite' => '%s v-a invitat să vă alăturați <strong>%s</strong>', 
));