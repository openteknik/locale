<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'com:ossn:invite' => 'Invitație', 
	 'com:ossn:invite:friends' => 'Invită prietenii', 
	 'com:ossn:invite:friends:note' => 'Pentru a invita prietenii să vi se alăture în această rețea, introduceți adresele lor de e-mail și un scurt mesaj. Ei vor primi un e-mail care conține invitația ta.', 
	 'com:ossn:invite:emails:note' => 'Adrese de e-mail (separate printr-o virgulă)', 
	 'com:ossn:invite:emails:placeholder' => 'smith@example.com, john@example.com', 
	 'com:ossn:invite:message' => 'Mesaj', 
	 'com:ossn:invite:mail:subject' => 'Invitație de a vă alătura %s', 
	 'com:ossn:invite:mail:message' => 'Ați fost invitați să vă alăturați %s de %s. Au inclus următorul mesaj:

%s

Pentru a vă alătura, faceți clic pe următorul link:

%s

Legătura de profil: %s
', 
	 'com:ossn:invite:mail:message:default' => 'Bună.

Am vrut să vă invit să vă alăturați rețelei mele aici, pe %s.

Legătura de profil: %s

Cu stimul.
%s', 
	 'com:ossn:invite:sent' => 'Prietenii tăi au fost invitaţi. Invitații trimise: %s.', 
	 'com:ossn:invite:wrong:emails' => 'Următoarele adrese nu sunt valabile: %s.', 
	 'com:ossn:invite:sent:failed' => 'Nu pot invita următoarele adrese: %s.', 
	 'com:ossn:invite:already:members' => 'Următoarele adrese sunt deja membre: %s', 
	 'com:ossn:invite:empty:emails' => 'Vă rugăm să adăugați cel puțin o adresă de e-mail', 
));