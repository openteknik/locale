<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'ossn:search' => 'Căutare', 
	 'result:type' => 'TIP REZULTAT', 
	 'search:result' => 'Rezultatele căutării pentru %s', 
	 'ossn:search:topbar:search' => 'Grupuri de căutare, prieteni şi multe altele.', 
	 'ossn:search:no:result' => 'Nici un rezultat găsit!', 
));