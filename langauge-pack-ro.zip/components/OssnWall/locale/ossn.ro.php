<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'ossnwall' => 'OssnWall', 
	 'post:created' => 'Post creat cu succes!', 
	 'post:create:error' => 'Nu pot crea post! Încearcă din nou mai târziu.', 
	 'post' => 'Post', 
	 'enter:location' => 'Introduceți locația', 
	 'tag:friends' => 'Tag Prieteni', 
	 'wall:post:container' => 'Ce e în mintea ta?', 
	 'post:view' => 'Post View', 
	 'ossn:post:delete' => 'Șterge', 
	 'post:delete:fail' => 'Nu se poate șterge post! Încearcă din nou mai târziu.', 
	 'post:delete:success' => 'Post șters cu succes!', 
	 'post:select:privacy' => 'Vă rugăm să selectați intimitate pentru perete post', 
	 'ossn:wall:settings:save:error' => 'Nu pot salva setările! Încearcă din nou mai târziu.', 
	 'ossn:wall:settings:saved' => 'Setări salvate!', 
	 'ossn:wall:admin:notice' => 'Homepage Posts', 
	 'ossn:wall:allsite:posts' => 'Toate mesajele site-ului', 
	 'ossn:wall:friends:posts' => 'Numai pentru prieteni', 
	 'ossn:wall:post:saved' => 'Post salvat cu succes', 
	 'ossn:wall:post:save:error' => 'Nu se poate salva post', 
));