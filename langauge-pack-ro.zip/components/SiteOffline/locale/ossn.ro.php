<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'siteoffline' => 'Site-ul offline', 
	 'siteoffline:online' => 'Online', 
	 'siteoffline:offline' => 'Offline', 
	 'siteoffline:save:error' => 'Nu pot salva setările', 
	 'siteoffline:saved' => 'Setările au fost salvate', 
	 'siteoffline:login' => 'Autentificare site-ul managerului', 
	 'siteoffline:login:error' => 'Numai admin login este permisă', 
	 'siteoffline:message' => 'Ne pare rău, site-ul nostru este temporar în jos pentru întreținere. Vă rugăm să verificați din nou în curând.', 
));