<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'banuser:unban' => 'Utilizator Unban', 
	 'banuser' => 'Ban utilizator', 
	 'banuser:invalid:user' => 'Utilizator invalid', 
	 'banuser:banned' => 'Utilizator interzis cu succes', 
	 'banuser:ban:failed' => 'Utilizator interzis a eșuat', 
	 'banuser:unbanned' => 'Utilizator nebanat cu succes', 
	 'banuser:unban:failed' => 'Utilizator unban a eșuat', 
	 'banuser:notice' => 'Acest utilizator a fost interzis de pe acest site pentru încălcarea termenilor site-ului.', 
	 'banuser:banned:login' => 'Ați fost interzis de pe acest site', 
));