<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'sociallogin' => 'Social Login', 
	 'social:login:settings:saved' => 'Setările au fost salvate', 
	 'social:login:settings:save:error' => 'Setările nu pot fi salvate', 
	 'social:login:app:secret' => 'APP Secret', 
	 'social:login:app:key' => 'ID APP', 
	 'social:login:facebook' => 'Facebook API detalii', 
	 'social:login:with:facebook' => 'Autentifica-te cu Facebook', 
	 'social:login:account:create:error' => 'Nu se poate loga, ceva a mers prost', 
	 'social:login:facebook:url' => 'OAuth redirect URI', 
	 'social:login:fill:profile' => 'Vă rugăm să completați profilul dvs.', 
	 'social:login:twitter' => 'Twitter', 
	 'social:login:consumer:key' => 'Cheie de consum API', 
	 'social:login:constumer:secret' => 'Client API Secret', 
	 'social:login:twitter:callback' => 'URL-ul callback', 
	 'social:login:with:twitter' => 'Autentificare cu Twitter', 
	 'social:login:google' => 'Google', 
	 'social:login:with:google' => 'Autentificare cu Google', 
	 'social:login:oauth:id' => 'ID client OAuth', 
	 'social:login:oauth:secret' => 'OAuth Client Secret', 
	 'social:login:apple' => 'Măr', 
	 'social:login:with:apple' => 'Autentificare cu Apple', 
	 'social:login:apple:clientid:service' => 'ID-ul clientului (ID de serviciu)', 
	 'social:login:apple:teamid' => 'ID de echipă', 
	 'social:login:appple:keyfileid' => 'ID-ul fișierului cheie', 
	 'social:login:appple:keyfile' => 'Keyfile', 
	 'social:login:appple:keyfilefound' => 'Găsit!', 
	 'social:login:button' => 'Buton', 
	 'social:login:enabled' => 'Activat', 
	 'social:login:disabled' => 'Dezactivat', 
));