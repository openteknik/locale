<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'rtcomments:typing' => 'Cineva tastează un comentariu ...', 
));