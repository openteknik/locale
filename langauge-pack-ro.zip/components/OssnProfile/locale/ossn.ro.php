<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'change:cover' => 'Schimbare de acoperire', 
	 'change:photo' => 'Schimbă fotografia', 
	 'update:info' => 'Informații actualizate', 
	 'message' => 'Mesaj', 
	 'save:position' => 'Salvează poziţia', 
	 'ossn:profile:picture:updated' => 'Am schimbat fotografia de profil.', 
	 'ossn:profile:cover:picture:updated' => 'S-a schimbat coperta.', 
	 'language' => 'Limbă', 
	 'edit:profile' => 'Editează profilul', 
	 'reposition:cover' => 'Repoziționarea', 
	 'profile:photos' => 'Fotografii de profil', 
	 'profile:cover:err1' => 'Acoperă imaginea prea mică', 
	 'profile:cover:err1:detail' => 'Imaginea de acoperire trebuie să fie cel puțin %s px x %s px sau mai mare.', 
));