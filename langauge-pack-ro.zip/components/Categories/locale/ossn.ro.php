<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'category' => 'Categorie', 
	 'categories' => 'Categorii de utilizatori', 
	 'categories:categry:add:failed' => 'Nu a reușit să adauge categorie', 
	 'categories:categry:added' => 'Categorie adăugată cu succes', 
	 'categories:categry:exists' => 'Categoria există deja', 
	 'category:title' => 'Nume (numai alfabete)', 
	 'category:description' => 'Descriere', 
	 'categories:alphabets:only' => 'Vă rugăm să folosiți numai alfabete în nume, fără spațiu sau caractere speciale.', 
	 'categories:delete:failed' => 'Nu se poate șterge categoria', 
	 'categories:categry:deleted' => 'Categorie eliminată cu succes', 
	 'categories:select' => '-Selectați categoria-', 
	 'categories:add' => 'Categorie Adaugă', 
));