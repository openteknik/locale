<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'gdpr:deleteaccount' => 'Șterge contul', 
	 'gdpr:account:deleted' => 'Contul dvs. a fost șters', 
	 'gdpr:account:delete:error' => 'Contul dvs. nu poate fi șters', 
	 'gdpr:confirm:signup' => 'Confirm că sunt de acord cu site-ul dvs. %s și %s', 
	 'gdpr:privacypolicy' => 'Politica de confidențialitate', 
	 'gdpr:signup:error' => 'Trebuie să confirmați că sunteți de acord cu site-ul nostru Termeni și Politica de confidențialitate', 
	 'gdpr:delete:account:notice' => 'Avertisment! Ștergerea contului va fi permanentă. Această acțiune nu este reversibilă.', 
));