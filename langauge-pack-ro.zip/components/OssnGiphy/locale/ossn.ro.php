<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'ossngiphy' => 'Giphy', 
	 'ossngiphy:powered' => 'Alimentat de GIPHY', 
));