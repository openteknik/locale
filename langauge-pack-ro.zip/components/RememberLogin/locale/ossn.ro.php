<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'com:rememberlogin:keep:login' => 'Ţine-mă conectat la', 
));