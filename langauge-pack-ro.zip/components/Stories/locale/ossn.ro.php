<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'stories' => 'Povești', 
	 'stories:title' => 'Titlu (opțional)', 
	 'stories:story:add' => 'Adaugă poveste', 
	 'stories:added' => 'Poveştile au fost salvate', 
	 'stories:add:failed' => 'Poveștile nu pot fi adăugate în sistem', 
	 'stories:deleted:status' => 'Starea a fost ștearsă', 
	 'stories:delete:failed' => 'Poveștile nu pot fi șterse', 
	 'stories:cron' => 'Cere furnizorului de hosting pentru a adăuga în urma cron loc de muncă pentru contul dvs. de hosting. Acest lucru va șterge povești vechi', 
));