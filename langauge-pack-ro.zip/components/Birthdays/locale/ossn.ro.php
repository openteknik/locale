<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'birthdays:upcoming' => 'Zilele de naștere viitoare', 
	 'birthdays:on' => '%s au ziua de naștere pe %d', 
	 'birthdays:nobirthday' => 'Fără zile de naştere!', 
));