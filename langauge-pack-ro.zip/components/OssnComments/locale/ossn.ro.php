<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'write:comment' => 'Scrie un comentariu ...', 
	 'like' => 'Like', 
	 'unlike' => 'Spre deosebire', 
	 'comment:deleted' => 'Comentariu șters cu succes!', 
	 'comment:delete:error' => 'Nu pot șterge comentariul! Încearcă din nou mai târziu.', 
	 'comment:delete' => 'Șterge', 
	 'comment:comment' => 'Comentariu', 
	 'comment:view:all' => 'Vezi toate comentariile', 
	 'comment:edit:success' => 'Comentariu a fost editat cu succes', 
	 'comment:edit:failed' => 'Nu se poate edita comentariul dvs.', 
));