<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'ossn:notifications:ossnpoke:poke' => '%s te-a înțepat!', 
	 'user:poked' => 'Ați poked %s!', 
	 'user:poke:error' => 'Nu pot scormoni %s! Încearcă din nou mai târziu.', 
	 'poke' => 'Traistă', 
));