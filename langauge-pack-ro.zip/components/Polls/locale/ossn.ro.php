<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'polls' => 'Sondaje', 
	 'polls:add' => 'Adaugă sondaj', 
	 'polls:poll' => 'Sondaj', 
	 'polls:title' => 'Titlul', 
	 'polls:option:title' => 'Titlu opțiune sondaj', 
	 'polls:add:option' => 'Adaugă opțiune', 
	 'polls:options' => 'Opțiuni', 
	 'polls:publish' => 'Publică sondaj', 
	 'polls:error:created' => 'Sondajul nu poate fi creat', 
	 'polls:success:created' => 'Sondajul a fost publicat cu succes pe perete', 
	 'polls:vote' => 'Vot', 
	 'polls:success:voted' => 'Votul dvs. a fost salvat pentru acest sondaj', 
	 'polls:failed:voted' => 'Nu se poate salva votul pentru acest sondaj', 
	 'polls:wall:created' => 'Sondaj creat', 
	 'polls:failed:end' => 'Nu se poate încheia acest sondaj', 
	 'polls:success:end' => 'Sondajul a fost încheiat', 
	 'polls:end' => 'Sfârșit', 
	 'polls:delete' => 'Șterge', 
	 'polls:embed' => 'Embed', 
	 'polls:ended' => 'Sondajul a fost încheiat', 
	 'ossn:notifications:comments:entity:poll_entity' => '%s a comentat sondajul dvs.', 
	 'ossn:notifications:like:entity:poll_entity' => '%s liked your poll', 
	 'polls:failed:delete' => 'Sondajul nu poate fi șters', 
	 'polls:success:delete' => 'Sondajul a fost șters', 
	 'polls:time' => 'Timpul creat', 
	 'polls:status' => 'Starea', 
	 'polls:status:ended' => 'Încheiat', 
	 'polls:status:opened' => 'Deschis', 
	 'polls:all' => 'Toate sondajele', 
	 'polls:group' => 'Grup', 
	 'polls:join:group' => 'Trebuie să vă alăturați grupului pentru a vedea sondajele', 
));