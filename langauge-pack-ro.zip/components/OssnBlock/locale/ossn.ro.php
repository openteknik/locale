<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'user:blocked' => 'Utilizatorul a fost blocat!', 
	 'user:block:error' => 'Nu pot bloca utilizatorul! Încearcă din nou mai târziu.', 
	 'user:block' => 'Bloc', 
	 'user:unblock' => 'Deblocare', 
	 'user:unblocked' => 'Utilizatorul a fost deblocat', 
	 'user:unblock:error' => 'Nu poate debloca utilizatorul', 
	 'ossn:blocked:error' => 'Blocat', 
	 'ossn:blocked:error:note' => 'Nu puteti vizualiza aceasta pagina pentru ca ati fost blocati de catre utilizator.', 
	 'ossn:profile:edit:tab' => 'Blocarea', 
	 'ossn:profile:list:text' => 'Această pagină conține lista persoanelor pe care le-a blocat.', 
));