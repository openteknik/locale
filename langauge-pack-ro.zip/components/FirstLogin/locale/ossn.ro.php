<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'firstlogin' => 'Prima autentificare', 
	 'first:login:url' => 'Introduceți adresa URL', 
	 'first:login:placeholder' => 'https://mysiteurl.com/[USERNAME]', 
	 'firstlogin:saved' => 'Setări salvate', 
	 'firstlogin:cannot:save' => 'Nu se poate salva setările', 
	 'first:login:info' => 'Mai jos sunt tag-urile pe care le puteti folosi in URL, <br /> [USERNAME] este numele de utilizator al utilizatorului care este logat.<br /> [GUID] este id-ul pentru utilizatorul loggedin.', 
));