<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'sentiment' => 'Sentiment', 
	 'sentiment:positive' => 'Pozitiv', 
	 'sentiment:negative' => 'Negativ', 
	 'sentiment:neutral' => 'Neutră', 
	 'sentiment:whocansee' => 'Cine poate vedea sentimentul?', 
	 'sentiment:admin' => 'Administratori', 
	 'sentiment:all' => 'Toată lumea', 
	 'sentiment:save:error' => 'Nu pot salva setările', 
	 'sentiment:saved' => 'Setările au fost salvate', 
	 'sentiment:username' => 'Nume utilizator API', 
	 'sentiment:email' => 'E-mail API', 
	 'sentiment:apikey' => 'API cheie', 
));