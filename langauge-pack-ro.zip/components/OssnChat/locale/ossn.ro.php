<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'ossn:chat:no:friend:online' => 'Fără prieteni online', 
));