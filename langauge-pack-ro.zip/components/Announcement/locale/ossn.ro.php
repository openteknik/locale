<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'announcement' => 'Anunț site', 
	 'announcement:title' => 'Anunț!', 
	 'announcement:save:error' => 'Anunțul nu a putut fi salvat', 
	 'announcement:saved' => 'Anunțul a fost salvat', 
	 'announcement:text' => 'Introduceți mesajul dvs. de anunț', 
	 'announcement:type' => 'Tipul anunțului', 
));