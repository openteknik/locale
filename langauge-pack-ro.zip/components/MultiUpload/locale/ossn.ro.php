<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'multiupload:text' => 'Vă rugăm să introduceți textul pentru postul dvs. de perete!', 
));