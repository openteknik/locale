<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'ossnnotifications' => 'Notificări', 
	 'ossn:notifications:comments:post' => '%s a comentat pe post.', 
	 'ossn:notifications:like:post' => '%s liked your post.', 
	 'ossn:notifications:like:annotation' => '%s liked your comment.', 
	 'ossn:notifications:like:entity:file:ossn:aphoto' => '%s ți-a plăcut fotografia ta.', 
	 'ossn:notifications:comments:entity:file:ossn:aphoto' => '%s a comentat pe fotografie.', 
	 'ossn:notifications:wall:friends:tag' => '%s te-a etichetat într-o postare.', 
	 'ossn:notification:are:friends' => 'Acum sunteţi prieteni!', 
	 'ossn:notifications:comments:post:group:wall' => '%s a comentat pe postul de grup.', 
	 'ossn:notifications:like:entity:file:profile:photo' => '%s a plăcut fotografia de profil.', 
	 'ossn:notifications:comments:entity:file:profile:photo' => '%s a comentat fotografia de profil.', 
	 'ossn:notifications:like:entity:file:profile:cover' => '%s a plăcut coperta de profil.', 
	 'ossn:notifications:comments:entity:file:profile:cover' => '%s a comentat pe coperta dvs. de profil.', 
	 'ossn:notifications:like:post:group:wall' => '%s liked your post.', 
	 'ossn:notification:delete:friend' => 'Cerere de prietenie șters!', 
	 'notifications' => 'Notificări', 
	 'see:all' => 'Vezi Toate', 
	 'friend:requests' => 'Cereri de prietenie', 
	 'ossn:notifications:friendrequest:confirmbutton' => 'Confirmă', 
	 'ossn:notifications:friendrequest:denybutton' => 'Neagă', 
	 'ossn:notification:mark:read:success' => 'Cu succes marcat tot ca citit', 
	 'ossn:notification:mark:read:error' => 'Nu poate marca tot ca citit', 
	 'ossn:notifications:mark:as:read' => 'Mark tot ca citit', 
	 'ossn:notifications:admin:settings:close_anywhere:title' => 'Închideți ferestrele de notificare dând click oriunde', 
	 'ossn:notifications:admin:settings:close_anywhere:note' => '<i class=\"fa fa-info-circle\"> <i class=\"fa fa-info-circle\"></i> închide orice fereastră de notificare făcând clic oriunde pe pagina<br><br>', 
	 'ossn:notifications:comments:entity:file:profile:photo:someone' => '%s a comentat fotografia de profil.', 
	 'ossn:notifications:comments:entity:file:profile:cover:someone' => '%s a comentat pe coperta profilului.', 
	 'ossn:notifications:comments:entity:file:ossn:aphoto:someone' => '%s a comentat fotografia.', 
	 'ossn:notifications:admin:settings:checkintervals:title' => 'Timp de verificare automată a notificării (Implicit 60 secunde)', 
));