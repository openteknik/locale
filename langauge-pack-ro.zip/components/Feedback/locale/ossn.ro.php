<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'feeback:desc' => 'Scrieți un feedback mai jos', 
	 'feeback:rate' => 'Experienţa generală:', 
	 'feedback:submit' => 'Trimiteți feedback', 
	 'feedback:added' => 'Feeback a fost adăugat', 
	 'feedback:add:failed' => 'Feedback nu poate fi adăugat', 
	 'feedback:from' => 'Din', 
	 'feedback:rate' => 'Rata', 
	 'feedback:delete' => 'Șterge', 
	 'feedback:message' => 'Mesaj', 
	 'feedback' => 'Feedback', 
	 'feedback:deleted' => 'Feedback-ul a fost șters', 
	 'feedback:deleted:error' => 'Feedback-ul nu poate fi șters', 
));