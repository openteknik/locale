<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'report' => 'Raportează asta.', 
	 'report:this' => 'Raportează asta.', 
	 'report:file:failed' => 'Raportul nu poate fi depus.', 
	 'report:filed' => 'A raportat cu succes elementul la administratorul site-ului.', 
	 'report:settings' => 'Conținutul raportat', 
	 'report:deleted' => 'Raportul a fost șters', 
	 'report:delete:error' => 'Raportul nu poate fi șters', 
	 'ossn:notifications:report' => '%s a raportat elementul.', 
	 'report:reason' => 'Motivul:', 
	 'report:reportedby' => 'Raportate De:', 
	 'report:time:created' => 'Timp', 
	 'report:view' => 'Vizualizare conținut', 
	 'report:read' => 'Mark Read', 
	 'report:type' => 'Tip', 
	 'report:data' => 'Date', 
));