<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'white:settings' => 'Setări', 
	 'admin:theme:white' => 'Setări', 
	 'theme:white:homepage:image' => 'Imaginea paginii de aterizare', 
	 'theme:goblue:logo:site' => 'Logo site', 
	 'theme:goblue:logo:admin' => 'Admin Logo', 
	 'theme:white:file:large' => 'Fișierul este prea mare! nu trebuie să fie mai mare de 500KB', 
	 'theme:white:darkmode' => 'Darkmode', 
	 'theme:white:litemode' => 'Litemode', 
	 'theme:white:default:mode' => 'Mod implicit', 
	 'theme:goblue:logo:large' => 'Fișier logo-ul este prea mare!', 
	 'theme:goblue:logo:failed' => 'Încărcați logo-ul', 
	 'theme:goblue:logo:changed' => 'Logo-ul a fost schimbat.', 
	 'theme:goblue:browercache' => 'În cazul în care imaginile nu apar. Vă rugăm să goliți cache-ul browser-ul web pentru a face imaginile apar', 
	 'home:top:heading' => 'Bun venit la %s!', 
	 'home:top:sub:heading' => 'Alăturați-vă acum pentru a face noi prieteni, crea grupuri, adăuga fotografii, și mult mai mult.', 
	 'com:latestmembers:latest:members' => 'Ultimele Membri', 
	 'darkmode:enable:darkmode' => 'Comutați la Darkmode', 
	 'site:register' => 'Înregistrare', 
	 'theme:white:latestmember:widget' => 'Cele mai recente membri widget', 
));