<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'admin:theme:awesome' => 'Setări minunate', 
	 'awesometheme:settings' => 'Setări minunate', 
	 'awesometheme:primary' => 'Albastru', 
	 'awesometheme:warning' => 'Portocaliu', 
	 'awesometheme:info' => 'Cerul albastru', 
	 'awesometheme:success' => 'Verde', 
	 'awesometheme:danger' => 'Roșu', 
	 'awesometheme:black' => 'Negru', 
	 'awesometheme:settings:saved' => 'Setări salvate', 
	 'awesometheme:settings:error' => 'Setările nu pot fi salvate', 
	 'theme:goblue:logo:site' => 'Logo site', 
	 'theme:goblue:logo:admin' => 'Admin Logo', 
	 'theme:goblue:logo:large' => 'Fișier logo-ul este prea mare!', 
	 'theme:goblue:logo:failed' => 'Încărcați logo-ul', 
	 'theme:goblue:logo:changed' => 'Logo-ul a fost schimbat.', 
	 'theme:goblue:browercache' => 'În cazul în care imaginile nu apar. Vă rugăm să goliți cache-ul browser-ul web pentru a face imaginile apar', 
	 'theme:goblue:background' => 'Fundal', 
	 'logo_images:settings' => 'Setări', 
	 'admin:theme:logoimg' => 'Fundal logo', 
));