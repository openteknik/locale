<?php
/**
* Translated locale
* ossn.ro.php
**/

ossn_register_languages('ro', array(
	 'goblue:settings' => 'GoBlue', 
	 'admin:theme:goblue' => 'GoBlue', 
	 'theme:goblue:logo:site' => 'Logo site', 
	 'theme:goblue:logo:admin' => 'Admin Logo', 
	 'theme:goblue:logo:large' => 'Fișier logo-ul este prea mare!', 
	 'theme:goblue:logo:failed' => 'Încărcați logo-ul', 
	 'theme:goblue:logo:changed' => 'Logo-ul a fost schimbat.', 
	 'theme:goblue:browercache' => 'În cazul în care imaginile nu apar. Vă rugăm să goliți cache-ul browser-ul web pentru a face imaginile apar', 
));