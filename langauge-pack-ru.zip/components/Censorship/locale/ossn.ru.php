<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'censorship' => 'Цензура', 
	 'censorship:add:words' => 'Введите слова ниже', 
	 'censorship:add:words:note' => 'Введите слова через запятую (,). Word1, Word2, Word3', 
	 'censorship:replace:string' => 'Введите строку для замены неверных слов', 
	 'censorship:fields:error' => 'Все поля являются обязательными', 
	 'censorship:saved' => 'Параметр сохранен', 
	 'censorship:save:error' => 'Не удалось сохранить параметры', 
));