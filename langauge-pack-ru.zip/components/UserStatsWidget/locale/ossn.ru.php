<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'userstats:friends' => 'Друзья', 
	 'userstats:comments' => 'Комментарии', 
	 'userstats:reactions' => 'Реакция', 
	 'userstats:posts' => 'Должности', 
));