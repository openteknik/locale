<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'passwordvalidation:atleast' => 'быть не менее <em>%s<em> символов', 
	 'passwordvalidation:passwordmustbe' => 'Пароль должен:', 
	 'passwordvalidation:capitalletter' => 'содержать прописную букву', 
	 'passwordvalidation:lowerletter' => 'содержать нижнюю букву', 
	 'passwordvalidation:number' => 'содержать число', 
	 'passwordvalidation:error' => 'Этот пароль не соответствует требованиям', 
));