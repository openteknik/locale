<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'firstlogin' => 'Первый вход', 
	 'first:login:url' => 'Введите URL', 
	 'first:login:placeholder' => 'https://mysiteurl.com/[USERNAME]', 
	 'firstlogin:saved' => 'Параметры сохранены', 
	 'firstlogin:cannot:save' => 'Не удалось сохранить параметры', 
	 'first:login:info' => 'Ниже представлены теги, которые можно использовать в URL, <br /> [ USERNAME]-имя пользователя, зарегистрированного в системе.<br /> [ GUID]-это ИД пользователя loggedin.', 
));