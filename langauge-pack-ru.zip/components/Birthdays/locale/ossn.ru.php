<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'birthdays:upcoming' => 'Предстоящие дни рождения', 
	 'birthdays:on' => '%s имеет день рождения %d', 
	 'birthdays:nobirthday' => 'Никаких дней рождения!', 
));