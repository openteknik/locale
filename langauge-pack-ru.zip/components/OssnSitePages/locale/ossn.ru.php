<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'ossnsitepages' => 'Страницы сайта', 
	 'site:privacy' => 'Конфиденциальность', 
	 'site:about' => 'О', 
	 'site:terms' => 'Правила и условия', 
	 'page:saved' => 'Страница успешно сохранена!', 
	 'page:save:error' => 'Не удалось сохранить страницу! Повторите попытку позже.', 
));