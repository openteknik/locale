<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'accesscode' => 'Код доступа', 
	 'accesscode:saved' => 'Код доступа сохранен.', 
	 'accesscode:save:error' => 'Не удалось сохранить код доступа', 
	 'accesscode:register:code' => 'Код доступа к коду доступа', 
	 'access:code:error' => 'Недопустимый код доступа', 
));