<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'ossn:search' => 'Поиск', 
	 'result:type' => 'ТИП РЕЗУЛЬТАТА', 
	 'search:result' => 'Результаты поиска для %s', 
	 'ossn:search:topbar:search' => 'Поисковые группы, друзья и многое другое.', 
	 'ossn:search:no:result' => 'Результаты не найдены!', 
));