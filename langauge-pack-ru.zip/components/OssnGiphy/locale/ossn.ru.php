<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'ossngiphy' => 'Гифи', 
	 'ossngiphy:powered' => 'На основе GIFI', 
));