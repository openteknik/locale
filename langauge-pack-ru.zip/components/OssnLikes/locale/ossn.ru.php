<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'people:like:this' => 'Люди, которые от реагировали на это!', 
	 'ossn:like:this' => '%s отреагировал на это', 
	 'ossn:like:you:and:this' => 'Вы и %s реагировали на это', 
	 'ossn:like:people' => '%s Люди', 
	 'ossn:like:person' => '%s Сотрудник', 
	 'ossn:liked:you' => 'Ты отреагировал на это.', 
	 'ossn:unlike' => 'В отличие', 
	 'ossn:like' => 'Как', 
));