<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'ossn:notifications:ossnpoke:poke' => '%s вас пукнул!', 
	 'user:poked' => 'Вы откололи %s!', 
	 'user:poke:error' => 'Невозможно poke %s! Повторите попытку позже.', 
	 'poke' => 'Poke', 
));