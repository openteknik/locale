<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'announcement' => 'Объявление сайта', 
	 'announcement:title' => 'Объявление!', 
	 'announcement:save:error' => 'Не удалось сохранить объявление', 
	 'announcement:saved' => 'Объявление было сохранено', 
	 'announcement:text' => 'Введите свое сообщение об объявлении', 
));