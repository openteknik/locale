<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'hashtag:trending' => 'Тенденции', 
	 'hashtag:counter' => '%s стеновые посты', 
));