<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'ossn:chat:no:friend:online' => 'Нет друзей в сети', 
));