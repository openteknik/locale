<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'userverified:success' => 'Проверка успешно выполнена', 
	 'userverified:failed' => 'Проверка завершилась неудачно', 
	 'userverified:verified' => 'Проверенный профиль', 
	 'userverified:verify' => 'Проверить', 
	 'userverified:unverify' => 'Отменить проверку', 
	 'userverified:unverifiy:success' => 'Непроверено успешно', 
	 'userverified:unverifiy:failed' => 'Непроверенная ошибка', 
));