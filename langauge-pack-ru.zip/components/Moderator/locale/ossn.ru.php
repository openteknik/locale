<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'moderator' => 'Сделать модератором', 
	 'can_moderate' => 'Пользователь может умеренные посты, комментарии, фотографии, группы', 
	 'delete:cover' => 'Удалить обложку', 
	 'moderator:yes' => 'Да', 
	 'moderator:no' => 'Нет', 
	 'moderate:users' => 'Умеренные пользователи', 
	 'moderator:delete:user' => 'Удалить пользователя', 
	 'moderator:select' => 'Выберите', 
));