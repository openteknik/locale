<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'hangout' => 'Звук/видеовызов', 
));