<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'stories' => 'Сюжеты', 
	 'stories:title' => 'Название (необязательно)', 
	 'stories:story:add' => 'Добавить историю', 
	 'stories:added' => 'Сюжеты сохранены', 
	 'stories:add:failed' => 'Сюжеты не могут быть добавлены в систему', 
	 'stories:deleted:status' => 'Состояние удалено', 
	 'stories:delete:failed' => 'Невозможно удалить сюжеты', 
	 'stories:cron' => 'Попросите поставщика хостинга добавить следующее задание хрона для вашей учетной записи хостинга. Это удалит старые истории', 
));