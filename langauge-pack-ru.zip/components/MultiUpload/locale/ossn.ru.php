<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'multiupload:text' => 'Введите текст для вашей настенной должности!', 
));