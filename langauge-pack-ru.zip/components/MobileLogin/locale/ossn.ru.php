<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'mobilelogin' => 'Мобильный', 
	 'mobilelogin:username' => 'Имя пользователя/Электронная почта/Мобильный', 
	 'mobilelogin:invalid:mobile' => 'Недопустимый номер мобильного устройства', 
	 'mobilelogin:num' => '+1245678910', 
	 'mobilelogin:mobile:exists' => 'Мобильный номер уже используется', 
));