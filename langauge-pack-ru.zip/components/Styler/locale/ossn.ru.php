<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'styler' => 'Стилер', 
	 'styler:brown' => 'Коричневый', 
	 'styler:blue' => 'Синий', 
	 'styler:darkyellow' => 'Темно-желтый', 
	 'styler:montego' => 'Монтего', 
	 'styler:green' => 'Зеленый', 
	 'styler:pink' => 'Розовый', 
	 'styler:red' => 'Красный', 
	 'styler:select:color' => 'Выберите цвет ниже', 
	 'styler:save:error' => 'Не удалось сохранить параметры', 
	 'styler:saved' => 'Параметры сохранены', 
));