<?php
/**
* Translated locale
* ossn.ru.php
**/

ossn_register_languages('ru', array(
	 'goblue:settings' => 'GoBlue', 
	 'admin:theme:goblue' => 'GoBlue', 
	 'theme:goblue:logo:site' => 'Логотип сайта', 
	 'theme:goblue:logo:admin' => 'Эмблема администратора', 
	 'theme:goblue:logo:large' => 'Слишком большой файл логотипа!', 
	 'theme:goblue:logo:failed' => 'Не удалось закачать логотип', 
	 'theme:goblue:logo:changed' => 'Логотип изменен.', 
	 'theme:goblue:browercache' => 'В случае, если изображения не отображаются. Очистим кэш веб-браузера, чтобы изображения отображались', 
));