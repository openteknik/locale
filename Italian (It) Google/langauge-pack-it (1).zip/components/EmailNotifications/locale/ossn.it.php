<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'mail:notfication:subject' => 'Hai una nuova notifica!', 
	 'email:notfication:main:body' => 'Ciao %s, 

[%S]

[%S]

[%S]
[%S]', 
	 'emailnotifications' => 'Notifiche e -mail', 
	 'notification:type:comments:entity:file:profile:photo' => 'Commento fotografico del profilo', 
	 'notification:type:like:post:group:wall' => 'Group Wall Post come', 
	 'notification:type:like:post' => 'Post a parete come', 
	 'notification:type:comments:post' => 'Pubblica commento', 
	 'notification:type:comments:post:group:wall' => 'COMMENTO POST POST DI GRUPPO', 
	 'notification:type:group:joinrequest' => 'Richiesta di iscrizione del gruppo', 
	 'notification:type:like:annotation' => 'Commento come', 
	 'notification:type:comments:entity:file:ossn:aphoto' => 'Commento fotografico dell\'album', 
	 'notification:type:ossnpoke:poke' => 'Colpire', 
	 'notification:type:wall:friends:tag' => 'Contrassegnato nel post muro', 
));