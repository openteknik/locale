<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'banuser:unban' => 'Utente unbn', 
	 'banuser' => 'Vietare l\'utente', 
	 'banuser:invalid:user' => 'Utente non valido', 
	 'banuser:banned' => 'L\'utente ha bandito correttamente', 
	 'banuser:ban:failed' => 'L\'utente è stato bandito non è riuscito', 
	 'banuser:unbanned' => 'Utente non è stato infastidito con successo', 
	 'banuser:unban:failed' => 'L\'utente non ha fallito', 
	 'banuser:notice' => 'Questo utente è stato bandito da questo sito Web per aver violato i termini del sito Web.', 
	 'banuser:banned:login' => 'Ti è stato bandito da questo sito Web', 
));