<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'birthdays:upcoming' => 'Compleanni in arrivo', 
	 'birthdays:on' => '%s Avere il compleanno su %d', 
	 'birthdays:nobirthday' => 'Nessun compleanno imminente!', 
));