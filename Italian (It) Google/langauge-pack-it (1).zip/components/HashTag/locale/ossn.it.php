<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'hashtag:trending' => 'Tendenza', 
	 'hashtag:counter' => '%s pali da muro', 
));