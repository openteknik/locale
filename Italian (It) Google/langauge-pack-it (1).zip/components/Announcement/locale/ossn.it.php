<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'announcement' => 'Annuncio del sito', 
	 'announcement:title' => 'Annuncio!', 
	 'announcement:save:error' => 'L\'annuncio non poteva essere salvato', 
	 'announcement:saved' => 'L\'annuncio è stato salvato', 
	 'announcement:text' => 'Inserisci il tuo messaggio di annuncio', 
));