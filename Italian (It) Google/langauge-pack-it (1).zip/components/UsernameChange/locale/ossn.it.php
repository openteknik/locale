<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'changeusername:ok' => 'Il nome utente è stato cambiato!', 
));