<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'groupinvite:widget:title' => 'Invita un amico', 
	 'groupinvite:widget:desc' => 'Seleziona i tuoi amici separati da una virgola e fai clic su Invia.', 
	 'groupinvite:invite' => 'Invitare', 
	 'groupinvite:sent' => 'È stato inviato l\'invito, il tuo amico riceverà una notfica sul tuo invito', 
	 'ossn:notifications:groupinvite' => '%s ti ha invitato a unirti al gruppo <strong> %s </strong>', 
));