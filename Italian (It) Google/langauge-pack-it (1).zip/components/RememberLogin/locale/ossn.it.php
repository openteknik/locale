<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'com:rememberlogin:keep:login' => 'Resta collegato', 
));