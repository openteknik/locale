<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'emembers' => 'Membri del sito', 
));