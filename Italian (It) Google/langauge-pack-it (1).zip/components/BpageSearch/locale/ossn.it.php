<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'fakeusers' => 'Utenti falsi', 
	 'fakeusers:created' => '%s Gli utenti falsi sono stati generati', 
));