<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'messenger' => 'Software Messenger', 
	 'messenger:head' => 'Puoi utilizzare i seguenti dettagli di accesso per il tuo messaggero:', 
	 'messenger:hostname' => 'Nome host', 
	 'messenger:username' => 'Nome utente', 
	 'messenger:password' => 'Password', 
	 'messenger:bottom' => 'Questo software è per il sistema operativo di Windows X64 Bit', 
	 'messenger:download' => 'Scarica Messenger', 
	 'messenger:use' => 'Messaggero', 
));