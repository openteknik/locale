<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'multiupload:text' => 'Inserisci il testo per il tuo post sul muro!', 
));