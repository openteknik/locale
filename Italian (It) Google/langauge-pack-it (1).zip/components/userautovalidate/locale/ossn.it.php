<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'account:created:email' => 'Via Konto Estas Regrita. Ensalutu vin en la retejon nun .....', 
));