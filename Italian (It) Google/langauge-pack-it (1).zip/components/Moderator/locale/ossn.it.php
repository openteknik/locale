<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'moderator' => 'Fare moderatore', 
	 'can_moderate' => 'L\'utente può moderare post, commenti, foto, gruppi', 
	 'delete:cover' => 'Elimina la copertura', 
	 'moderator:yes' => 'SÌ', 
	 'moderator:no' => 'NO', 
	 'moderate:users' => 'Utenti moderati', 
	 'moderator:delete:user' => 'Elimina l\'utente', 
	 'moderator:select' => 'Seleziona', 
));