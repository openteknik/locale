<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'censorship' => 'Censura', 
	 'censorship:add:words' => 'Inserisci le parole qui sotto', 
	 'censorship:add:words:note' => 'Immettere parole separate da una virgola (,). Word1, Word2, Word3', 
	 'censorship:replace:string' => 'Immettere la stringa per sostituire le parole cattive con', 
	 'censorship:fields:error' => 'Tutti i campi sono richiesti', 
	 'censorship:saved' => 'L\'impostazione è stata salvata', 
	 'censorship:save:error' => 'Non è possibile salvare le impostazioni', 
));