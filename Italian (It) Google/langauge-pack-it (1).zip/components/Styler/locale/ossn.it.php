<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'styler' => 'Styler', 
	 'styler:brown' => 'Marrone', 
	 'styler:blue' => 'Blu', 
	 'styler:darkyellow' => 'Giallo scuro', 
	 'styler:montego' => 'Montego', 
	 'styler:green' => 'Verde', 
	 'styler:pink' => 'Rosa', 
	 'styler:red' => 'Rosso', 
	 'styler:select:color' => 'Seleziona il colore sotto', 
	 'styler:save:error' => 'Non è possibile salvare le impostazioni', 
	 'styler:saved' => 'Le impostazioni sono state salvate', 
));