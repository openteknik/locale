<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'userverified:success' => 'Verificato con successo', 
	 'userverified:failed' => 'Verificato non riuscito', 
	 'userverified:verified' => 'Profilo verificato', 
	 'userverified:verify' => 'Verificare', 
	 'userverified:unverify' => 'Non verificare', 
	 'userverified:unverifiy:success' => 'Non verificato con successo', 
	 'userverified:unverifiy:failed' => 'Non verificato fallito', 
));