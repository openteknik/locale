<?php
/**
* Translated locale
* ossn.it.php
**/

ossn_register_languages('it', array(
	 'mobilelogin' => 'Mobile', 
	 'mobilelogin:username' => 'Nome utente/email/mobile', 
	 'mobilelogin:invalid:mobile' => 'Numero di cellulare non valido', 
	 'mobilelogin:num' => ' 1245678910', 
	 'mobilelogin:mobile:exists' => 'Un numero di cellulare è già in uso', 
));