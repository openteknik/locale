<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'styler' => '(تايلر)', 
	 'styler:brown' => 'بني', 
	 'styler:blue' => 'أزرق', 
	 'styler:darkyellow' => 'أصفر داكن', 
	 'styler:montego' => 'مونتيغو', 
	 'styler:green' => 'أخضر', 
	 'styler:pink' => 'وردي', 
	 'styler:red' => 'أحمر', 
	 'styler:select:color' => 'اختيار لون بأسفل', 
	 'styler:save:error' => 'لا يمكن حفظ المحددات', 
	 'styler:saved' => 'تم حفظ المحددات', 
));