<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'censorship' => 'الرقابة', 
	 'censorship:add:words' => 'أدخل الكلمات التالية', 
	 'censorship:add:words:note' => 'أدخل الكلمات التي تم تشبيحها بفاصلة (,). Word1 ، Word2 ، Word3', 
	 'censorship:replace:string' => 'أدخل مجموعة الحروف لاستبدال الكلمات غير السئ ـ ب', 
	 'censorship:fields:error' => 'كل المجالات مطلوبة', 
	 'censorship:saved' => 'تم حفظ المحددات', 
	 'censorship:save:error' => 'لا يمكن حفظ المحددات', 
));