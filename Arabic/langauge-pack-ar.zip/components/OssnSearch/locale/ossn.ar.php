<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'ossn:search' => 'بحث', 
	 'result:type' => 'نوع النتيجة', 
	 'search:result' => 'نتائج البحث الى %s', 
	 'ossn:search:topbar:search' => 'مجموعات بحث ، أصدقاء وأكثر.', 
	 'ossn:search:no:result' => 'لم يتم ايجاد نتائج !', 
));