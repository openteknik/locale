<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'ossngiphy' => 'Giphy', 
	 'ossngiphy:powered' => 'يتم تشغيله بواسطة GIPHY', 
));