<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'moderator' => 'جعل المنسق', 
	 'can_moderate' => 'يمكن أن يكون المستخدم معتدلا ، تعقيبات ، صور ، مجموعات', 
	 'delete:cover' => 'حذف الغطاء', 
	 'moderator:yes' => 'نعم.', 
	 'moderator:no' => 'لا', 
	 'moderate:users' => 'مستخدمين معتدلون', 
	 'moderator:delete:user' => 'حذف مستخدم', 
	 'moderator:select' => 'برجاء تحديد', 
));