<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'mobilelogin' => 'موبايل', 
	 'mobilelogin:username' => 'Username / Email / Mobile', 
	 'mobilelogin:invalid:mobile' => 'رقم التليفون المحمول غير صحيح', 
	 'mobilelogin:num' => '+1245678910', 
	 'mobilelogin:mobile:exists' => 'يتم استخدام رقم التليفون المحمول بالفعل', 
));