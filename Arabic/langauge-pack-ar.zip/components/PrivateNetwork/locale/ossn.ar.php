<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'com:private:network:deney' => 'يجب أن تقوم ببدء الاتصال قبل مشاهدة هذه الصفحة', 
));