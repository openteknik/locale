<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'feeback:desc' => 'كتابة الملاحظات الخاصة بك بأسفل', 
	 'feeback:rate' => 'التجربة الإجمالية :', 
	 'feedback:submit' => 'احالة التعليق التقييم', 
	 'feedback:added' => 'تم اضافة Feback', 
	 'feedback:add:failed' => 'لا يمكن اضافة التعليق التقييمي', 
	 'feedback:from' => 'من', 
	 'feedback:rate' => 'المعدل', 
	 'feedback:delete' => 'حذف', 
	 'feedback:message' => 'الرسالة', 
	 'feedback' => 'المعلومات المرجعية', 
	 'feedback:deleted' => 'تم حذف التعليق التقييمي', 
	 'feedback:deleted:error' => 'لا يمكن حذف التعليق التقييمي', 
));