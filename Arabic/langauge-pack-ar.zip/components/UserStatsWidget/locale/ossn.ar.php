<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'userstats:friends' => 'أصدقاء', 
	 'userstats:comments' => 'التعليقات', 
	 'userstats:reactions' => 'ردود الافعال', 
	 'userstats:posts' => 'الوظائف', 
));