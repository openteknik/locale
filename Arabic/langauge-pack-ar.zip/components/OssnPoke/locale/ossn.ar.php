<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'ossn:notifications:ossnpoke:poke' => '%s كان قد كدس لك !', 
	 'user:poked' => 'لقد قمت باستدعاء %s !', 
	 'user:poke:error' => 'لا يمكن استدعاء %s ! برجاء اعادة المحاولة فيما بعد.', 
	 'poke' => 'سبوزة', 
));