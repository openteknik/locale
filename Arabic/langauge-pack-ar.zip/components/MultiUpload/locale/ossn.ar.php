<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'multiupload:text' => 'برجاء ادخال النص لنقطة الحائط الخاصة بك !', 
));