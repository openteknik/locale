<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'groupinvite:widget:title' => 'دعوة صديق', 
	 'groupinvite:widget:desc' => 'حدد أصدقائك الذين تم تحديدهم بواسطة فاصلة ثم اضغط ارسال.', 
	 'groupinvite:invite' => 'دعوة', 
	 'groupinvite:sent' => 'الدعوة أرسلت ، صديقك سيستلم a notication حول دعوتك.', 
	 'ossn:notifications:groupinvite' => '%s قام بدعوتك للانضمام الى مجموعة <strong>%s</strong>', 
));