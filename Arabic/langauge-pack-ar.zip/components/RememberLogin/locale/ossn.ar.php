<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'com:rememberlogin:keep:login' => 'الاحتفاظ بي تم بدء الاتصال', 
));