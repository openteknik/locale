<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'userverified:success' => 'تم التحقق بنجاح', 
	 'userverified:failed' => 'فشل التحقق', 
	 'userverified:verified' => 'ملف مواصفات متحقق', 
	 'userverified:verify' => 'التحقق', 
	 'userverified:unverify' => 'الغاء التحقق', 
	 'userverified:unverifiy:success' => 'تم الغاء التحقق بنجاح', 
	 'userverified:unverifiy:failed' => 'فشل غير مؤكد', 
));