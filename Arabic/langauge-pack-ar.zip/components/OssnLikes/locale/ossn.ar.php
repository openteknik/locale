<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'people:like:this' => 'الناس الذين تفاعلت مع هذا !', 
	 'ossn:like:this' => '%s رد على هذا', 
	 'ossn:like:you:and:this' => 'قمت أنت و %s برد فعل على هذا', 
	 'ossn:like:people' => '%s أشخاص', 
	 'ossn:like:person' => '%s شخص', 
	 'ossn:liked:you' => 'لقد تفاعلت على هذا', 
	 'ossn:unlike' => 'على عكس', 
	 'ossn:like' => 'مثل', 
));