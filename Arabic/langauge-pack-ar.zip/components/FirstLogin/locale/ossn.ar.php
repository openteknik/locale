<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'firstlogin' => 'بدء الاتصال الأول', 
	 'first:login:url' => 'أدخل عنوان URL', 
	 'first:login:placeholder' => 'https://mysiteurl.com/ [ USERNAME ]', 
	 'firstlogin:saved' => 'تم حفظ المحددات', 
	 'firstlogin:cannot:save' => 'لا يمكن حفظ المحددات', 
	 'first:login:info' => 'فيما يلي الشارات التي يمكنك استخدامها في URL ، <br /> [ USERNAME ] هو اسم مستخدم المستخدم الذي قام ببدء الاتصال.<br /> [ GUID ] هو الكود الخاص بمستخدم loggedin.', 
));