<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'banuser:unban' => 'الغاء حظر مستخدم', 
	 'banuser' => 'حظر المستخدم', 
	 'banuser:invalid:user' => 'مستخدم غير صحيح', 
	 'banuser:banned' => 'تم حظر المستخدم بنجاح', 
	 'banuser:ban:failed' => 'فشل في منع المستخدم', 
	 'banuser:unbanned' => 'تم الغاء حظر المستخدم بنجاح', 
	 'banuser:unban:failed' => 'فشل في الغاء حظر المستخدم', 
	 'banuser:notice' => 'تم حظر هذا المستخدم من هذا الموقع لانتهاكه مصطلحات الموقع.', 
	 'banuser:banned:login' => 'لقد تم منعك من هذا الموقع', 
));