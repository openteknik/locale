<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'rtcomments:typing' => '... شخص ما يقوم بكتابة تعليق', 
));