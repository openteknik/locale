<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'passwordvalidation:atleast' => 'على الأقل <em>%s<em> حروف طويلة', 
	 'passwordvalidation:passwordmustbe' => 'كلمة السرية الخاصة بك يجب :', 
	 'passwordvalidation:capitalletter' => 'يحتوي على حرف رأس', 
	 'passwordvalidation:lowerletter' => 'يحتوي على حروف سفالة', 
	 'passwordvalidation:number' => 'يحتوي على رقم', 
	 'passwordvalidation:error' => 'لا تتفق كلمة السرية هذه مع المتطلبات', 
));