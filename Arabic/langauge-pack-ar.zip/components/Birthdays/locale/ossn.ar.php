<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'birthdays:upcoming' => 'أعياد الميلاد القادمة', 
	 'birthdays:on' => '%s لديه عيد ميلاد على %d', 
	 'birthdays:nobirthday' => 'لا أعياد ميلاد قادمة', 
));