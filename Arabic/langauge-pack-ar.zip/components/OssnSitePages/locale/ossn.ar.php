<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'ossnsitepages' => 'صفحات الموقع', 
	 'site:privacy' => 'الخصوصية', 
	 'site:about' => 'نبذة عن', 
	 'site:terms' => 'الشروط والأحكام', 
	 'page:saved' => 'تم حفظ الصفحة بنجاح !', 
	 'page:save:error' => 'لا يمكن حفظ الصفحة ! برجاء اعادة المحاولة فيما بعد.', 
));