<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'ossn:chat:no:friend:online' => 'لا أصدقاء على الإنترنت', 
));