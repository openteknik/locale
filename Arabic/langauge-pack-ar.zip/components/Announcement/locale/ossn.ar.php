<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'announcement' => 'اعلان الموقع', 
	 'announcement:title' => 'إعلان !', 
	 'announcement:save:error' => 'لا يمكن حفظ الاشعار', 
	 'announcement:saved' => 'تم حفظ الاشعار', 
	 'announcement:text' => 'أدخل رسالة الاشعار الخاصة بك', 
	 'announcement:type' => 'نوع الإعلان', 
));