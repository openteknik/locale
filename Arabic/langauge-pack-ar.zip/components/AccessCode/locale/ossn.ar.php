<?php
/**
* Translated locale
* ossn.ar.php
**/

ossn_register_languages('ar', array(
	 'accesscode' => 'كود التوصل', 
	 'accesscode:saved' => 'تم حفظ شفرة الاستخدام.', 
	 'accesscode:save:error' => 'لا يمكن حفظ شفرة الاستخدام', 
	 'accesscode:register:code' => 'كود Accesscode / Sigup Code', 
	 'access:code:error' => 'كود اتصال غير صحيح', 
));